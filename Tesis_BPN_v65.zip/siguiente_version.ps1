# =====================================================================
#  DONDE SE GUARDAN LAS VERSIONES, Y CUAL TOCA
#
#  Imprime DOS lineas:
#      1) la ruta de la carpeta donde viven las versiones
#      2) el numero que le toca a la proxima
#
#  POR QUE BUSCA LA CARPETA EN VEZ DE SUBIR UN NUMERO FIJO DE NIVELES
#
#      La version anterior subia exactamente dos niveles desde este
#      archivo. Eso funcionaba mientras el manuscrito vivio en
#      Nueva carpeta\Tesis_BPN_v60\Tesis_BPN\ , pero el 19 de septiembre
#      de 2026 la carpeta de trabajo se movio a Nueva carpeta\MANUSCRITO\ ,
#      un nivel mas arriba, y la cuenta dejo de valer. Un script que
#      depende de a que profundidad esta guardado se rompe en silencio la
#      primera vez que alguien reorganiza las carpetas.
#
#      Ahora sube nivel por nivel hasta encontrar una carpeta que YA
#      contenga versiones guardadas (Tesis_BPN_v*.zip o el PDF de vista
#      previa). Esa es, por definicion, la carpeta de versiones.
#
#  QUE CUENTA
#      El zip y el PDF de vista previa. Basta que sobreviva uno de los dos
#      para que el numero no se repita.
# =====================================================================

function Tiene-Versiones([string]$d) {
    if (-not (Test-Path -LiteralPath $d)) { return $false }
    $z = Get-ChildItem -LiteralPath $d -Filter 'Tesis_BPN_v*.zip' -EA SilentlyContinue
    $p = Get-ChildItem -LiteralPath $d -Filter 'Tesis_BPN_vista_previa_v*.pdf' -EA SilentlyContinue
    return (($z.Count + $p.Count) -gt 0)
}

# --- 1. Localizar la carpeta de versiones -----------------------------
$base = $null
$d = Split-Path -Parent $PSScriptRoot
while ($d) {
    if (Tiene-Versiones $d) { $base = $d; break }
    $padre = Split-Path -Parent $d
    if ($padre -eq $d) { break }   # llegamos a la raiz del disco
    $d = $padre
}

# Si no hay ninguna version todavia, se usa la carpeta que contiene a esta.
if (-not $base) { $base = Split-Path -Parent $PSScriptRoot }

# --- 2. El numero que toca --------------------------------------------
$mayor = 0
foreach ($item in Get-ChildItem -LiteralPath $base -EA SilentlyContinue) {
    $nombre = if ($item.PSIsContainer) { $item.Name } else { $item.BaseName }
    if ($nombre -match '^Tesis_BPN.*v(\d+)$') {
        $n = [int]$Matches[1]
        if ($n -gt $mayor) { $mayor = $n }
    }
}

Write-Output $base
Write-Output ($mayor + 1)
