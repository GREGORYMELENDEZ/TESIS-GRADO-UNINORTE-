# Bitácora del proyecto — Tesis BPN Colombia

Documento de control. Registra el estado de cada capítulo y los cambios que se
van haciendo. **No forma parte de la tesis**: no se compila ni se entrega.

---

## v61 — 18 de septiembre de 2026 · SIN COMPILAR TODAVÍA

**Aviso:** esta versión se editó sin poder compilar, porque una actualización de Windows
(KB5124008, del 8 de septiembre) dejó sin acceso el entorno de compilación. **Hay que
compilar y verificar antes de darla por buena.** Los tres controles de siempre:

    grep -c "Citation.*undefined" main.log     debe dar 0
    grep -c "Reference.*undefined" main.log    debe dar 0
    grep "^!" main.log                         no debe devolver nada

Comprobado a mano que las nueve referencias cruzadas usadas existen: `sec:dss`, `sec:bpn`,
`sec:mediacion`, `sec:preparacion`, `ap:validacion`, `cap:objetivos`, `sec:fase-multinivel`,
`sec:fase-modelos` y `sec:limitaciones`.

### Resumen y abstract cerrados

Se añaden los resultados a `secciones/resumen.tex`, en español y en inglés: prevalencia
global y por período, puntos de unión, índices de desigualdad con sus cotas, reparto de la
descomposición, variación territorial, y la inversión del gradiente educativo como resultado
central. Queda una nota roja para el párrafo de la Fase 7.

Corregida además una inconsistencia del abstract, que decía «nonparametric bootstrap with
1,000 replicates» mientras el resumen en español describe un bootstrap paramétrico sobre los
datos agrupados. Ahora coinciden.

### Capítulo 6 escrito

Ocho secciones, una por pregunta específica más las contribuciones y el alcance. **Las ocho
limitaciones que ya estaban se conservan íntegras**, con dos añadidos: la cuantificación del
subregistro diferencial por régimen de afiliación (13,8 veces) y la corrección de los
asteriscos de Markdown que habían quedado sin convertir a `\textbf{}`.

Queda una nota roja en §6.7, capacidad predictiva, a la espera de la Fase 7.

### Capítulo 7 escrito

Tres secciones por destinatario. Se abre por las recomendaciones al sistema de información
porque son las que se derivan más directamente de hallazgos propios: la tabla de
equivalencias entre regímenes de codificación, el registro del peso en gramos, la auditoría
de la completitud diferencial y la documentación de la ausencia estructural en los metadatos.

---

## Cómo trabajar capítulo a capítulo

1. Abre en Overleaf **solo** el archivo del capítulo que vas a tocar, dentro de
   la carpeta `capitulos/`.
2. Edita, compila (`Recompile`) y revisa.
3. Anota el cambio en la tabla de abajo con la fecha.
4. `main.tex` no se toca nunca, salvo que quieras reordenar capítulos.

Overleaf guarda el historial automáticamente: **History**, arriba a la derecha,
te muestra las diferencias entre versiones y permite volver atrás.

---

## Estado por capítulo

| Archivo | Capítulo | Estado | Falta |
|---|---|---|---|
| `capitulos/cap1_introduccion.tex` | 1. Introducción | **Terminado** | — |
| `capitulos/cap2_objetivos.tex` | 2. Objetivos | Terminado | — |
| `capitulos/cap3_marco_teorico.tex` | 3. Marco teórico | **Terminado** | — |
| `capitulos/cap4_metodologia.tex` | 4. Metodología | Terminado | Versiones de librerías y cifras de la tabla de muestra |
| `capitulos/cap5_resultados.tex` | 5. Resultados | Esqueleto anotado | Todo. Cada sección indica qué debe contener |
| `capitulos/cap6_conclusiones.tex` | 6. Conclusiones | Esqueleto | Todo |
| `capitulos/cap7_recomendaciones.tex` | 7. Recomendaciones | Esqueleto | Todo |
| `secciones/resumen.tex` | Resumen y abstract | Casi listo | Resultados numéricos |

Todo lo pendiente está marcado con `\pendiente{...}` y sale **en rojo** en el PDF.
Para encontrarlo: busca `\pendiente` en los archivos.

---

## Decisiones tomadas

| Tema | Decisión |
|---|---|
| Fuente de datos | Estadísticas Vitales (EEVV) del DANE, 1998–2024. **No** SIVIGILA |
| Software | Python 3.9 con scikit-learn, pandas, pyreadstat, statsmodels |
| Estilo de citas | **Autor-año**, `(Amjad et al., 2019)`. natbib + apalike |
| Posición socioeconómica | Nivel educativo materno y régimen de afiliación. Las EEVV no captan estrato ni ingreso |
| Modelos predictivos | Logística, Lasso, Ridge, Árbol, Random Forest, **Gradient boosting**, Red neuronal. Siete en total |
| Contraste jerárquico | Opción B: boosting con departamento codificado vs. logístico multinivel (CCI, MOR, contracción) |
| Título | Desigualdades socioeconómicas, étnicas y territoriales en el bajo peso al nacer en Colombia: análisis multinivel y predictivo de las estadísticas vitales, 1998–2024 |

---

## Bloqueado: necesito estos datos de ti

1. ~~Nombre del supervisor~~ — resuelto: Lihki José Rubio Ortega.
2. ~~Enlace del repositorio~~ — resuelto:
   `https://github.com/GREGORYMELENDEZ/TESIS-GRADO-UNINORTE-` (**ojo: termina en guion**).
   Repositorio público. `crosswalk.yaml` ya subido.
   **Falta:** la estructura del repositorio no coincide con la que describe el Apéndice A.
   El repo tiene `DATA/` y `PAPERS/`; el Apéndice promete `datos/`, `scripts/`, `analisis/`,
   `figuras/`, `salidas/`, `requirements.txt` y `README.md`.
3. ~~Autores de Zhang et al. (2025)~~ — resuelto vía Crossref: Xue Zhang, Athar Ali Shah,
   Lu Han.

## Pendiente de verificar tras la integración de la matriz

- **Reconciliar la Tabla 4.1 con la matriz construida.** La tabla reporta 18.008.809 de
  base y 17.403.963 de muestra analítica. Las 167 filas corridas y los 34.551 duplicados
  se marcan pero no se excluyen; confirmar que los conteos siguen cuadrando.
- ~~Verificar que ningún análisis cruce regímenes de `ESQUEMA_CODIGOS`~~ — declarado como
  regla transversal en §4.4. **Falta aplicarlo en el código** cuando se corran los análisis.
- **Definir y documentar el mapeo educativo a la escala común de 4 niveles.** El texto lo
  anuncia; hay que fijar la equivalencia exacta y verificarla contra los tres formatos de
  escritura, en particular el de 2012–2013 sin cero de relleno.
- **Calcular los cuatro escenarios de sensibilidad** del Cuadro 5.2.

## Puntos abiertos que hay que resolver

1. **Peso al nacer en categorías, no en gramos.** En los microdatos `PESO_NAC`
   viene en 8 bandas de 500 g. El BPN se construye con las categorías 1 a 4.
   No existe el peso continuo.
2. **El corte de 37 semanas.** `T_GES` agrupa "de 28 a 37" y "de 38 a 41", así
   que las 37 semanas caen del lado del pretérmino. Hay que declarar el corte en
   38 semanas como limitación, o abandonar la estratificación término/pretérmino.
3. **Etnia y régimen solo desde 2008.** El análisis de esos dos ejes se restringe
   a 2008–2024.
4. **`IDPERTET` se llama `IDPUEBLOIN` en 2012 y 2013.** Si el script busca solo
   el primer nombre, pierde dos años sin avisar.
5. **Referencia 11 incompleta.** Faltan las iniciales del primer autor (Zhang) y
   el resto de la lista. Tomarlas de Wiley Online Library.
6. **Verificar la afirmación sobre Guarnizo-Herreño (2021).** El texto sostiene
   que no descompusieron la variación geográfica ni trataron la etnia como eje
   autónomo. Confirmar en el artículo original.

---

## Registro de cambios

| Fecha | Archivo | Qué se hizo |
|---|---|---|
| 2026-09-07 | `cap4_metodologia.tex` | C3: precisado que los 44 conceptos se materializan en 45 nombres de campo (`IDPUEBLOIN`/`IDPERTET`) |
| 2026-09-07 | `cap4_metodologia.tex` | **C4: regla transversal de estratificación** al inicio de §4.4. Declara que ningún análisis cruza regímenes en las 7 variables con ruptura, y define los dos procedimientos: recodificación a escala común de 4 niveles y restricción de período |
| 2026-09-07 | `cap5_resultados.tex` | **C5: nueva sección de sensibilidad a la completitud del registro** con los cuatro escenarios de imputación y el criterio de robustez |
| 2026-09-07 | `cap4_metodologia.tex` | **Integrada la construcción real de la matriz.** §4.3.1 ampliada con la verificación empírica (41 máximo anual vs 45 unión del período) y las tres incidencias de formato. §4.3.2 sustituida: naturaleza categórica de `PESO_NAC` y validación de pertenencia al diccionario en lugar de rangos continuos. §4.3.4 ampliada con la operacionalización del NaN estructural y la decisión sobre duplicados |
| 2026-09-07 | `cap4_metodologia.tex` | Tres subsecciones nuevas: §4.3.5 Infraestructura (Parquet + DuckDB), §4.3.6 Construcción de la matriz analítica (dos capas, `ESQUEMA_CODIGOS`, los seis regímenes) y §4.3.7 Trazabilidad |
| 2026-09-07 | `cap4_metodologia.tex` | Corregido §4.2.3: retirada la afirmación de que existe forma continua del desenlace. `PESO_NAC` es categórica en los 27 años |
| 2026-09-08 | `cap3_marco_teorico.tex` | **Tres subsecciones nuevas en §3.4.2**: información mutua condicional (ec. nueva), información de interacción (ec. nueva) y selección secuencial. Incluye la cifra de la simulación: I(X;Y)=0,000001 bits frente a I(X;Y\|Z)=0,018642 |
| 2026-09-08 | `cap4_metodologia.tex` | **§4.4.2 reescrita**: de cinco pasos marginales a **seis pasos** con selección secuencial condicional. Criterio de retención **por dos vías** (marginal O condicional). Párrafo nuevo sobre el límite de la estimación condicional: el procedimiento se detiene por agotamiento de estratos, no por falta de información |
| 2026-09-08 | `bibliothesis.bib` | battiti1994 y vergara2013, verificadas en Crossref. Total 59 a 61 |
| 2026-09-08 | `CODIGO_VSC/src/cribado.py` | Nuevo. IM marginal, condicional e interacción; nulo por permutación; selección hacia adelante; matriz de sinergia. Idéntico a `sklearn` hasta el decimal 12 y varios órdenes de magnitud más rápido |
| 2026-09-08 | `CODIGO_VSC/notebooks/02_cribado_mi.ipynb` | Nuevo. 29 celdas. Corre entero sobre la base completa: 0 fallos, pico de 1,63 GB |

| 2026-09-08 | `cap4_metodologia.tex` | **Tabla 4.1 reconciliada con el código.** El guion no aplicaba dos de las tres exclusiones declaradas (sin gestación, sin residencia): faltaban 244.757 registros. Corregido `src/datos.py`. Cifras vigentes: muestra **17.376.860 (96,49 %)**, prevalencia **8,78 %**, 1.525.772 casos. Añadida Exclusión 4 (duplicados y formato, 27.167) |
| 2026-09-08 | `cap4_metodologia.tex` | **Nuevo párrafo: operacionalización de la Exclusión 3.** Los centinelas `CODPTORE=1` (departamento ignorado, 16.328 registros) y `CODPTORE=75` (residencia en el exterior, 2.170) no vienen como nulo en 1998–2013. Con la regla completa, la Exclusión 3 coincide con el cuadro preliminar en **24 de 27 años** |
| 2026-09-08 | `cap4_metodologia.tex` | Nuevo párrafo: **territorio de residencia, no de ocurrencia**. La Exclusión 3 opera sobre CODPTORE/CODMUNRE. Usar el lugar del parto produciría un mapa de oferta hospitalaria en vez de desigualdad territorial |
| 2026-09-08 | `cap5_resultados.tex` | Cifras actualizadas: 17.383.790 / 96,53 % / 8,78 % / 1.526.484 casos; prevalencia de 7,64 % en 1998 a 11,15 % en 2024 (+45,9 %). **Escrito el resultado de tendencia**: CPA +1,170 % (IC 95 %: +0,960 a +1,380) y el párrafo de cobertura del registro como amenaza a la validez (r = −0,853). Un `\pendiente` menos |
| 2026-09-08 | `CODIGO_VSC/src/datos.py` | `muestra_analitica()` reescrita: las tres exclusiones del manuscrito en cadena, más las marcas de calidad. Devuelve la Tabla 4.1 con `detalle=True` |
| 2026-09-08 | `CODIGO_VSC/src/mapas.py` | Nombres de territorio en el hover, encabezado de líderes por año, carrera de barras, tabla de liderazgo y cambios de posición con ρ de Spearman |
| 2026-09-08 | `CODIGO_VSC/notebooks/08_mapas.ipynb` | **Corregido: los mapas usaban COD_DPTO/COD_MUNIC (ocurrencia del parto).** Ahora usan CODPTORE/CODMUNRE (residencia de la madre). El notebook falla explícitamente si faltan, en vez de caer de vuelta a ocurrencia |

| 2026-09-08 | `cap3_marco_teorico.tex` | **Nueva Sección 3.4.2, Información mutua.** Entropía de Shannon, IM, incertidumbre simétrica, sesgo por cardinalidad, estimador KSG/Ross para el caso mixto, mRMR, y un bloque explícito de ámbito legítimo de aplicación. 3 ecuaciones numeradas nuevas. La sección previa de $\chi^2$ y $V$ de Cramér pasó a subsección |
| 2026-09-08 | `cap4_metodologia.tex` | **Nueva Fase 2, Cribado de variables por información mutua**, insertada después del EDA. Fases 2 a 6 renumeradas a 3 a 7. Procedimiento en 5 pasos, criterio de retención por percentil 95 del nulo por permutación, control de fuga dentro del pliegue, y declaración explícita de que el cribado NO se aplica a los modelos multinivel |
| 2026-09-08 | `cap5_resultados.tex` | Nueva Sección 5.2 de resultados del cribado, con `\pendiente`. Actualizados los cruces: seis a siete fases, Fase 6 a Fase 7, Fase 5 a Fase 6 |
| 2026-09-08 | `bibliothesis.bib` | 7 referencias nuevas, **todas verificadas contra Crossref**: shannon1948, cover2006, ross2014, kraskov2004, peng2005, steuer2002, heinze2018. Total 52 a 59 |
| 2026-09-08 | `scripts/02_cribado_mi.py` | Nuevo. Implementa exactamente los 5 pasos declarados en la Fase 2. Probado de extremo a extremo sobre base sintética de 60.000 filas, 0 errores. Exige la columna `PARTICION` y avisa si no existe |

| 2026-08-24 | `bibliothesis.bib` | Referencia de Zhang et al. (2025) completada. Cero ocurrencias de PENDIENTE. Añadido Chen y Guestrin (2016) |
| 2026-08-24 | `cap4_metodologia.tex` | Fase 6 reescrita: partición aleatoria + temporal (1998–2018 / 2019–2024), imputación solo sobre entrenamiento, validación cruzada anidada, mediadores en el componente predictivo, regularización del MLP, corte temporal de historia obstétrica, independencia del índice de privación |
| 2026-08-24 | `cap4_metodologia.tex` | Armonización formalizada como esquema canónico + crosswalk, con los tres estados y la separación entre ausencia estructural y ausencia por ítem |
| 2026-08-24 | `datos/crosswalk.yaml` | Nuevo. Los 44 conceptos versionados en texto plano, validado como YAML |
| 2026-08-24 | `cap3_marco_teorico.tex` | Nueva subsección de gradient boosting (ec. de la función objetivo) y nueva subsección de contraste jerárquico (Opción B) |
| 2026-08-24 | `cap5_resultados.tex` | Añadidos: cuadro de brecha entrenamiento-prueba, sección de partición temporal y sección de contraste jerárquico |
| 2026-08-24 | `cap6_conclusiones.tex` | Seis limitaciones redactadas, incluida la del identificador materno |
| 2026-08-24 | `resumen.tex`, `siglas.tex` | Actualizados a siete modelos; añadidas siglas GBM y XGBoost |
| 2026-08-15 | (todos) | Proyecto dividido en archivos por capítulo. Contenido sin cambios: 66 páginas, texto idéntico a la versión anterior |
| 2026-08-15 | `cap3_marco_teorico.tex` | Escritas las cuatro secciones pendientes: 3.1 Determinantes sociales de la salud (con Cuadro 3.1 de correspondencia), 3.2 Definición y mecanismos del BPN, 3.10 Confusión y mediación (con Figura 3.1, grafo acíclico dirigido), 3.11 Datos faltantes (con ecuaciones de las reglas de Rubin). Capítulo 3 sin `\pendiente` |
| 2026-08-15 | `bibliothesis.bib` | Añadidas 4 referencias: CSDH 2008, Hernán y Robins 2020, VanderWeele 2015, Rubin 1976 |
| 2026-08-15 | `preambulo.tex` | Añadido `tikz` para el grafo causal |
| 2026-08-17 | `cap1_introduccion.tex` | Introducción condensada de ~6 a 2,5 páginas (987 palabras, 7 párrafos). Se conservan todas las citas |
| 2026-08-17 | `cap1_introduccion.tex` | Escrita la Sección 1.2 Justificación: relevancia sanitaria, distributiva, metodológica y para la política pública, más los 6 resultados esperados. Capítulo 1 sin `\pendiente` |
| 2026-08-17 | `preambulo.tex` + tablas | Flotantes de `[H]` a `[!htbp]` y parámetros de colocación. Corrige las medias páginas en blanco de la pág. 32 |
| 2026-08-17 | `scripts/` | Nuevo `tabla_4_1_flujo_muestra.py`: calcula la Tabla 4.1 sobre todos los años y genera el LaTeX |
| 2026-08-17 | `preambulo.tex` | Añadido `indentfirst`: el primer párrafo de cada capítulo y sección ahora lleva sangría como los demás |
| 2026-08-17 | `preambulo.tex` + `main.tex` | Citas cambiadas de numérico a **autor-año**: natbib `[round,authoryear]` + `\bibliographystyle{apalike}` |
| 2026-08-17 | `apendices/apA_codigo.tex` | Eliminados los bloques de código. Reemplazado por espacio para el enlace de GitHub, contenido del repositorio y condiciones de reproducibilidad |
| 2026-08-17 | `cap4_metodologia.tex` + `cap5` | **2012 corregido** con `Nacimientos_2012.txt` (676.835 registros). Totales recalculados: base 18.008.809, muestra 17.403.963 (96,64 %), prevalencia global 8,82 %. Retirada la advertencia sobre el archivo incompleto |
| 2026-08-17 | `cap4_metodologia.tex` | Tabla 4.1: añadida columna de porcentaje sobre la base original y fila de total excluido |
| 2026-08-17 | `cap4_metodologia.tex` | **Tabla 4.1 completada** con los 27 años procesados: 17.870.249 nacidos vivos, muestra analítica de 17.267.221 (96,63 %). Se fusionaron las exclusiones 3 y 4 (redundantes) y se añadió el análisis de completitud y del efecto migratorio venezolano |
| 2026-08-17 | `cap5_resultados.tex` | Escritas 5.1.1 y 5.1.4 con datos reales. Nueva Figura 5.1: prevalencia anual 1998–2024, del 7,67 % al 11,24 % |
| 2026-08-17 | `scripts/` | Añadido `tabla_4_1_por_anio.csv` con el detalle de las exclusiones y la prevalencia por año |
| 2026-08-17 | `cap3_marco_teorico.tex` | Sección 3.8 ampliada con las formulaciones completas: función de probabilidad y función de pérdida de cada modelo. Nueva subsección de notación. 26 ecuaciones numeradas en el capítulo |
| 2026-08-17 | `datos_trabajo.tex` | Título cambiado. Se retira «entre los departamentos» y se añade «y predictivo» para cubrir el componente de modelos. Título en inglés actualizado en paralelo |
| 2026-08-17 | `secciones/resumen.tex` | Resumen y abstract alineados con el nuevo título: se añade el párrafo sobre los seis modelos de clasificación y las palabras clave «aprendizaje automático» / «machine learning» |
| 2026-08-17 | `cap5_resultados.tex` + `preambulo.tex` | Corregida la página en blanco (pág. 43). Causa: títulos encadenados sin texto. Se añadió una nota de contenido bajo cada sección y `\raggedbottom`. Verificado: cero páginas vacías en todo el documento |
| | | |
| | | |

---

## Decisión metodológica registrada — 2026-09-08

**Alcance de la información mutua.** Se incorpora como (a) medida descriptiva de
asociación junto a la $V$ de Cramér y (b) filtro de variables **exclusivamente** dentro
del componente predictivo (Fase 7).

**No** se usa para eliminar covariables de los modelos logísticos multinivel. Razón:
seleccionar covariables por asociación marginal con el desenlace sesga las estimaciones
puntuales e invalida la cobertura nominal de los intervalos de confianza, porque la
incertidumbre del proceso de selección no entra en la varianza (Heinze, Wallisch y
Dunkler, 2018). Un confusor puede tener IM marginal baja y seguir siendo indispensable.

**Corrección del sesgo por cardinalidad.** Se adopta incertidumbre simétrica más nulo
por permutación específico de cada variable (500 réplicas, umbral en el percentil 95).
En la prueba sobre datos sintéticos donde el municipio era ruido puro, la IM bruta de
`CODMUNRE` (0,0455 bits) fue **la más alta de todas las variables**, y su propio nulo
por permutación dio p95 = 0,0467 bits. Es decir: toda esa señal aparente era
cardinalidad. Ese resultado sirve como demostración empírica en la sustentación.

### Pendiente de esta línea

- Ejecutar `02_cribado_mi.py` sobre la base real, ya particionada
- Poblar el Cuadro 5.2 con la salida de `cribado_mi.csv`
- Reescribir con voz propia los párrafos de justificación de §4.4.2, sobre todo el
  bloque de ámbito de aplicación, que es el que habrá que defender oralmente

---

## Reconciliación de la muestra analítica — 2026-09-08

**El problema.** El código producía 17.648.720 registros y el manuscrito declaraba
17.403.963. Diferencia: 244.757.

**La causa.** `muestra_analitica()` solo excluía los registros sin peso. Las otras dos
exclusiones que la Tabla 4.1 declara —sin edad gestacional y sin territorio de residencia—
no estaban implementadas. No era un desacuerdo de criterio: era código incompleto.

**Lo que quedó sin explicar, y por qué se decidió así.** Aplicadas las tres exclusiones, el
código da 17.411.002 y el cuadro preliminar decía 17.403.963. La diferencia, 7.039
registros, está **íntegramente** en la Exclusión 3 de los años 1998–2007 y 2012–2013: el
guion original detectaba territorios ausentes que la matriz actual ya no tiene, porque
entre medias se incorporó la recodificación de valores centinela. Los quince años restantes
coinciden registro a registro.

**Decisión: manda la versión reproducible.** Las cifras del manuscrito se actualizan a las
que produce el guion versionado, no al revés. Ajustar el código hasta reproducir un número
calculado por un guion que ya no existe sería un ejercicio de ingeniería inversa sin
respaldo metodológico, y ante el jurado la pregunta relevante no es cuál cifra estaba
antes en el documento sino cuál puede reproducirse desde el repositorio. La diferencia es
del 0,12 % y la prevalencia global pasa de 8,82 a 8,78 %: no altera ninguna conclusión.

**Cifras vigentes**

```
base original            18.008.809
  sin peso                  332.369    -1,85 %
  sin edad gestacional      207.982    -1,16 %
  sin residencia             57.456    -0,32 %
  duplicados y formato       27.212    -0,15 %
muestra analítica        17.383.790    96,53 %
casos de BPN              1.526.484
prevalencia global             8,78 %
CPA (Poisson robusta)         +1,170 %  IC 95 %: +0,960 a +1,380
r volumen-prevalencia         -0,853
```

### Pendiente de esta línea

- Recalcular las cifras de control de 2012 (`n_2012_filtrado`, `casos_2012`) con las cuatro
  exclusiones; las que hay en `config.py` son de la versión anterior
- Volver a ejecutar `08_mapas.ipynb`: los mapas actuales se construyeron sobre **ocurrencia
  del parto**, no sobre residencia. Los resultados territoriales publicados hasta ahora no
  son válidos
- Decidir la agregación del mapa municipal: con `n >= 50` anual se suprime el 45,8 % de las
  celdas. En quinquenios con `n >= 100` se conserva el 68,7 %


---

## Corrección de la reconciliación — 2026-09-08 (segunda pasada)

**Lo que se dijo antes era incompleto.** La primera reconciliación concluyó que el cuadro
preliminar procedía de un guion superado y que la diferencia de 7.039 registros era
irreducible. Era falso, y lo detectó el autor al ver dos códigos extraños en el gráfico de
barras.

**Lo que faltaba.** La Exclusión 3 no consiste solo en retirar los campos vacíos:

| Código | Significado | Registros | Años |
|---|---|---:|---|
| `CODPTORE = 1` | departamento de residencia ignorado, siempre con `CODMUNRE = 999` | 16.328 | 1998–2013 |
| `CODPTORE = 75` | residencia habitual **en el exterior**; `CODMUNRE` lleva el código del país, no un municipio | 2.170 | 1998–2013 |
| `CODPTORE` nulo | el instrumento deja el campo vacío | 51.953 | 2008–2024 |

El texto del manuscrito ya decía «incluidas las madres con residencia habitual en el
exterior». Era `CODPTORE = 75`. La implementación lo había perdido; el documento tenía
razón.

Con la regla completa, la Exclusión 3 coincide **exactamente** con el cuadro preliminar en
24 de los 27 años. El residuo son 56 registros repartidos entre 2004, 2005 y 2006.

**Cifras definitivas**

```
base original            18.008.809
  sin peso                  332.369    -1,85 %
  sin edad gestacional      207.982    -1,16 %
  sin residencia             64.431    -0,36 %
  duplicados y formato       27.167    -0,15 %
muestra analítica        17.376.860    96,49 %
casos de BPN              1.525.772
prevalencia global             8,78 %
```

**Lecciones que valen para el resto del análisis**

1. Un código sin nombre en un gráfico es un síntoma, no un defecto estético. `01`, `75` y
   `nan` aparecieron en el eje del gráfico de barras porque estaban dentro de la muestra.
2. `astype(str)` sobre una columna con nulos produce la cadena `"nan"`, que no es nula y se
   propaga hasta las etiquetas. Corregido en `codigo_divipola()` con `astype("string")`.
3. La ausencia se codifica de forma distinta según el régimen de `ESQUEMA_CODIGOS`. Una
   regla uniforme aplicada sin comprobar por año deja fuera parte del problema.

---

## Cribado por información mutua: de marginal a condicional — 2026-09-08

**Decisión del director:** el cribado se hace por información mutua, sin excepción.

**El problema que eso planteaba.** La información mutua marginal es ciega a las relaciones
puramente interactivas. Como el componente predictivo busca precisamente interacciones, un
filtro previo marginal sería contradictorio con el propósito del análisis.

**La solución: seguir con información mutua, pero condicional.** Misma teoría, mismas
unidades. Lo único que cambia es sobre qué se condiciona. Es la línea de Battiti (1994),
Peng et al. (2005) y Vergara y Estévez (2013).

**Demostración, 200.000 casos simulados** con dos determinantes cuyo efecto depende solo de
que coincidan:

```
I(B;Y)      = 0,000001 bits   nulo p95 = 0,000015   -> NO supera: sería eliminada
I(B;Y | A)  = 0,018642 bits   -> 17.538 veces más
interacción = +0,018641 bits  -> sinergia
```

Contraste con una variable con efecto principal: condicional ≈ marginal, interacción ≈ 0.

**Resultado sobre la base real** (submuestra de 400.000 de entrenamiento):

```
H(Y) = 0,4309 bits   (43,1 % de la incertidumbre máxima de una binaria)

paso 1: T_GES      I(X;Y)   = 0,111245   ENTRA
paso 2: MUL_PARTO  I(X;Y|S) = 0,008890   ENTRA
paso 3: NUMCONSUL  I(X;Y|S) = 0,002639   ENTRA
paso 4: N_HIJOSV   I(X;Y|S) = 0,002705   ENTRA
paso 5: NIV_EDUM   I(X;Y|S) = 0,003918   ENTRA
paso 6: NIV_EDUP   I(X;Y|S) = 0,005763   NO supera -> se detiene por agotamiento
```

**Hallazgo sustantivo, matriz de interacción (105 pares).** Los cuatro determinantes
sociales presentan **sinergia positiva con el número de consultas prenatales**:

```
SEG_SOCIAL × NUMCONSUL   +0,001540
NIV_EDUM   × NUMCONSUL   +0,001394
NIV_EDUP   × NUMCONSUL   +0,001194
IDPERTET   × NUMCONSUL   +0,000564
```

Es acceso a servicios, y es exactamente la interacción que una descomposición lineal
atribuiría de forma incorrecta a los efectos principales. Material del Paper 2, no un
control técnico.

**Los determinantes sociales entre sí son independientes** (todos por debajo de 0,0003): no
hay redundancia entre educación, régimen y etnia. Argumento a favor de conservarlos todos.

### Advertencia que queda registrada

La edad gestacional aporta 0,111 bits, doscientas veces más que el nivel educativo materno.
Es un **mediador**: está más cerca del desenlace en la cadena causal y absorbe la
información. Si el cribado decidiera la especificación de los modelos multinivel,
conservaría mediadores y expulsaría confusores. Por eso el descarte se limita al componente
predictivo de la Fase 7, y así queda declarado en §4.4.2.

---

# v29 · Integración de los resultados del análisis (Fases 3, 4 y 6)

## Qué se añadió

**Apéndice B — Validación del estimador multinivel** (`apendices/apB_validacion.tex`,
`\label{ap:validacion}`, llamado desde `main.tex` tras el Apéndice A).

Documenta por qué la estimación no usa las bibliotecas habituales y, sobre todo, que el
método **no es original**: es el modelo estándar de interceptos aleatorios con aproximación
de Laplace, el mismo que aplica `lme4` por defecto. Lo original es la implementación. Decir
«se desarrolló un estimador nuevo» sería sobreafirmar, y el apéndice lo dice explícitamente.

Cifras verificadas que contiene (todas de `A1_validacion_estimador.ipynb`, sobre datos
simulados con parámetros conocidos):

```
statsmodels: converge a 50 y 200 grupos; NO converge a 500
el análisis necesita 1.157 conglomerados
matriz que exigiría: 1,2 GB (M1) y 5,8 GB (M2)

agregación individual vs binomial:   8,1e-07   -> exacta
sesgo b1:                           +0,00036
sesgo sigma_muni:                   +0,00020
sesgo sigma_dpto:                   -0,01080   <- 20x mayor
correlación efectos est./reales:     0,9755 (muni) · 0,9749 (dpto)
varianza dptal nula -> estimada:     0,030
Laplace vs cuadratura de 15 nodos:   1,2e-08 (b1, muchos nacimientos)
                                     9,7e-04 (sigma, un nacimiento)
```

**Limitación declarada sin esperar al jurado:** el sesgo de $\sigma_{dpto}$ es veinte veces
mayor porque se estima sobre **33 departamentos** frente a 1.157 municipios. Consecuencia que
atraviesa todo el Capítulo 5: las conclusiones sobre variación **municipal** descansan en una
estimación sustancialmente más firme que las referidas a variación **departamental**.

## Qué se reescribió

**§4.4.4 Fase 4** — rehecha por completo. Antes describía cuatro modelos M0–M3 con M3 =
privación municipal (IPM). Ahora son **cinco, M0–M4**, y el IPM desaparece:

| | Añade | Estima | Objetivo |
|---|---|---|---|
| M0 | nada | variación territorial bruta | OE5 |
| M1 | 4 determinantes sociales | efecto **total** | — |
| M2 | edad, paridad, multiplicidad | efecto **independiente** | **OE3** |
| M3 | etnia | descontada la composición étnica | — |
| M4 | consultas prenatales | efecto **directo** | — |

Se añadieron además seis párrafos que antes no existían:

1. **«Una sola especificación ajustada en cinco pasos»** — cierra la confusión entre los
   cinco *ajustes* de la Fase 4 y las siete *técnicas* de la Fase 7. La respuesta a «¿cuántos
   modelos tiene su trabajo?» queda escrita en el manuscrito: no son doce.
2. **Estructura común** — 1.157 municipios en 33 departamentos, anidamiento estricto,
   territorio de **residencia** y no de ocurrencia.
3. **Comparabilidad entre ajustes** — cada comparación sobre la misma submuestra, y la razón
   del orden: `IDPERTET` no existe antes de 2008 y cuesta el 43 % de la muestra, por lo que va
   después del ajuste obstétrico para que M2 se estime sobre el **91,8 %**.
4. **Multiplicidad como covariable de precisión** — V de Cramér 0,2419 con el desenlace y
   0,0106 con la educación. Resuelto con datos, no por convención.
5. **Referencias de las categóricas** — incluida la advertencia de que educación y estado
   conyugal se leen en direcciones opuestas.
6. **Limitación del efecto étnico** — los interceptos municipales lo absorben (V de Cramér
   0,473 con municipio). El coeficiente mide lo que la etnia aporta *por encima del lugar de
   residencia*.

**§5.4** — renumerada a M0–M4 con las cifras ya obtenidas incrustadas en los `\pendiente`, y
una subsección nueva: el contraste entre la razón de momios de soltera (1,287) y la MOR
municipal (1,184).

**§4.4.2** — el $V$ de Cramér ahora declara la corrección de \citet{bergsma2013}.

**§4.4.6 Fase 6** — párrafo nuevo de **cotas por ausencia de información** (Manski): se
recalcula el indicador asignando a todos los faltantes primero el valor que minimiza la
desigualdad y después el que la maximiza. No exige supuesto MAR.

## Bibliografía

Tres entradas nuevas. Las dos primeras **verificadas en Crossref**:

- `breslow1993` — JASA 88(421):9–25 · DOI 10.1080/01621459.1993.10594284
- `bergsma2013` — J. Korean Stat. Soc. 42(3):323–328 · DOI 10.1016/j.jkss.2012.10.002
- `manski1990` — **SIN VERIFICAR**. Es *American Economic Review, Papers and Proceedings*,
  anterior a los DOI, y no figura en Crossref. Los datos (80(2):319–323) van comentados como
  no confirmados en el `.bib`. **Compruébalo en JSTOR antes de entregar.**

## Corrección de erratas

`\label{sec:armonizacion}` estaba **duplicada** en `cap4_metodologia.tex` (líneas 233 y 237):
la sección y su primera subsección compartían etiqueta, de modo que toda referencia cruzada
apuntaba a la subsección. La sección pasa a `sec:preparacion`. Se añadió `sec:faltantes` al
tratamiento de valores faltantes y `sec:fase-multinivel` a la Fase 4.

## Estado de compilación

```
0 errores · 0 citas sin resolver · 0 referencias sin resolver · 113 páginas
39 marcas \pendiente  (cap4: 2 · cap5: 35 · cap6: 1 · cap7: 1)
```

## Lo que queda abierto

- **La contradicción del IPM.** §4.2.3 sigue anunciando indicadores agregados de privación
  municipal como predictores de nivel 2, pero la decisión fue excluirlos y M3 ya no los lleva.
  Hay que quitar ese anuncio o justificar por qué se abandonó. Un jurado lo encuentra.
- **§4.3.6 sigue describiendo la imputación múltiple** como procedimiento principal, mientras
  la Fase 6 ya trabaja con cotas. Queda un `\pendiente` señalándolo.
- M2, M3 y M4 **sin ejecutar**; Fases 5 y 7 sin construir.
- Falta cita para el efecto del estado conyugal sobre el peso al nacer.
- Verificar si existe IPM municipal para 2005 o solo NBI.

---

# v30 · Verificación de Manski y resolución de la contradicción del IPM

## Manski (1990) queda verificado, por vía indirecta

El artículo es *American Economic Review, Papers and Proceedings*, anterior a la asignación
de DOI, y **no tiene ficha propia en Crossref**. No se puede verificar de forma directa.

Sí se verificó de forma **indirecta y autorizada**: la lista de referencias depositada en
Crossref por Horowitz y Manski (2000) —DOI 10.1080/01621459.2000.10473902, entrada CIT0015—
registra `Manski C. F., 1990, American Economic Review Papers and Proceedings, volume 80,
first-page 319`. Volumen y página inicial quedan así confirmados por un depósito editorial.
El número de ejemplar (2) es el que corresponde siempre a Papers and Proceedings.

El comentario del `.bib` ya no dice «VERIFICAR»: explica qué está confirmado y cómo.

**Se añadió además `horowitz2000`, verificado en Crossref** (JASA 95(449):77–84). Es la
referencia metodológicamente más ajustada al uso que se le da aquí: Manski (1990) desarrolla
cotas para efectos de tratamiento, mientras que Horowitz y Manski (2000) tratan específicamente
**cotas con datos faltantes en covariables y desenlace**, que es el problema de esta tesis. La
Fase 6 cita ahora ambas.

## La contradicción del IPM: se retiró el anuncio

Se optó por **eliminar la promesa y justificar el abandono**, no por conservar el indicador.

Razón de fondo, y es la que conviene sostener ante el jurado: **el objetivo específico 5 no
necesita el IPM.** Pregunta qué proporción de la variación es territorial y si persiste tras
ajustar por la composición individual. Ambas cantidades se estiman con interceptos aleatorios
y el contraste M0 → M1. Ninguna requiere una covariable municipal observada.

El argumento para el abandono es de **comparabilidad temporal**: el IPM y el NBI solo se
publican para años censales, y la serie abarca 1998–2024. Un valor censal aplicado a toda la
serie introduce error de medición creciente con la distancia al año censal, justo en el
período donde se concentra el hallazgo sobre la evolución de la desigualdad.

### Cambios concretos

- **§4.2.3** — el anuncio «cuando estén disponibles, se incorporan indicadores agregados de
  privación municipal» se sustituye por un párrafo titulado **«Ausencia de covariables
  agregadas de privación municipal»** que declara la decisión, la justifica y acota qué se
  pierde: se puede establecer *cuánta* variación es territorial, no *a qué* se debe.
- **§4.4.7** — se eliminó el párrafo «Independencia del índice de privación municipal», que
  seguía hablando del índice «empleado como predictor de nivel 2 en el Modelo 3». Estaba
  doblemente desactualizado: ni existe el índice ni el Modelo 3 es ése.
- **Cap. 6** — las limitaciones pasan de seis a **ocho**. Las dos nuevas:
  1. *Variación territorial sin covariables contextuales observadas.*
  2. *Precisión desigual de las dos componentes de varianza* (33 departamentos frente a
     1.157 municipios; sesgo veinte veces mayor, según el Apéndice B).

## Estado de compilación

```
0 errores · 0 citas sin resolver · 0 referencias sin resolver · 113 páginas
```

---

# v31 · Figuras de los notebooks y mapas

## Figuras incorporadas (15 nuevas)

Todas en PDF vectorial, procedentes de `CODIGO_VSC/salidas/figuras/`.

**Capítulo 4**

| Figura | Archivo | Dónde |
|---|---|---|
| 4.2–4.4 | `fig_armonizada_EDUC4_MADRE`, `_ESTCIV5`, `_SEG4` | antes de §4.3.2 Consistencia |
| 4.6 | `completitud_por_anio` | §4.3.4 Valores faltantes |

**Capítulo 5**

| Figura | Archivo | Dónde |
|---|---|---|
| 5.1 | `fig_5_1_prevalencia_anual` | §5.1.4 — **sustituye** a `prevalencia_bpn_1998_2024` |
| 5.2 | `fig_amenaza_cobertura` | §5.1.4, tras el párrafo de la amenaza |
| 5.3 | `mapa_municipios_1998` + `_2024` | §5.1.5 |
| 5.4 | `mapa_departamentos_1998` + `_2024` | §5.1.5 |
| 5.5 | `fig_matriz_v_cramer` | §5.2 |
| 5.6 | `fig_matriz_interaccion` | §5.2 |
| 5.7 | `fig_curva_concentracion_educacion` | §5.3.2 |
| 5.8 | `fig_sii_educacion` | §5.3.3 |
| 5.9 | `fig_serie_anual_desigualdad` | §5.3.4 |
| 5.10 | `fig_comparacion_ordenamientos` | §5.7 |

La figura antigua `prevalencia_bpn_1998_2024` queda en `figuras/` pero ya no se llama desde
ningún capítulo. Puede borrarse.

`completitud_por_año.pdf` se copió como **`completitud_por_anio.pdf`**: la eñe en un nombre
de archivo rompe la compilación en Overleaf.

## Mapas: cuatro paneles, recortados

Los mapas se insertan en pares 1998 / 2024 con `minipage` al 49 % y subrótulos (a) y (b),
de modo que la comparación temporal quede dentro de una sola figura y un solo pie.

Van recortados con `trim` porque cada PNG traía un **título interno** que duplicaba el pie de
figura y, además, dejaba márgenes blancos que empequeñecían el mapa:

```
mapa_municipios_1998      trim=58 24 7 55
mapa_municipios_2024      trim=58 24 7 54
mapa_departamentos_1998   trim=72 24 6 55
mapa_departamentos_2024   trim=72 24 6 55
```

**Esto es un parche.** Lo correcto es quitar `set_title` en el notebook y regenerar; entonces
se retira el `trim`. Queda un `\pendiente` señalándolo.

Se verificó que los dos años **comparten escala de color** en cada nivel (0–14 municipal,
0–12 departamental). Sin esa condición la comparación visual no sería válida.

## Mapas HTML: recomendación adoptada

No se incrustan en el documento. Un PDF no ejecuta JavaScript, y un PDF con material
interactivo embebido depende del lector que use el jurado. Se optó por:

- **Sección nueva en el Apéndice A**, «Material cartográfico interactivo», que los enumera y
  declara explícitamente que **ningún resultado defendido depende de consultarlos**. Esa frase
  importa: si el jurado no abre los HTML, la tesis sigue en pie.
- Los tres archivos son autocontenidos y se abren sin conexión.

## Erratas corregidas de paso

- El Apéndice A decía **«los seis modelos de clasificación»**. Son **siete** en todo el resto
  del documento. Corregido.
- Se añadió `mapas/` al inventario del repositorio.

## Pendientes que abren estas figuras

- Redactar la lectura de los cuatro mapas (hay un `\pendiente` con los tres puntos que los
  mapas soportan).
- **Advertencia obligatoria:** en municipios con pocos nacimientos la prevalencia es
  inestable, y los extremos del mapa pueden reflejar tamaño de muestra y no riesgo. Los
  interceptos aleatorios corrigen esto por contracción; las coropletas no. Declararlo antes de
  que lo pregunte el jurado.
- El eje horizontal de `fig_5_1_prevalencia_anual` dice **«Ano de ocurrencia»**, sin tilde.
  Corregir en el notebook y regenerar.
- Los mapas municipales tienen zonas en gris sin entrada en la leyenda. El pie ya lo explica,
  pero sería mejor un parche gris rotulado «sin registros» dentro de la figura.

## Estado de compilación

```
0 errores · 0 citas sin resolver · 0 referencias sin resolver · 120 páginas
```


---

# v32 · Figuras de evolución por código del EDA (notebook 01)

## Las cuatro que faltaban

Se incorporaron las figuras de composición y prevalencia por **código original**, que son la
evidencia visual de la ruptura semántica de 2008:

| Figura | Archivo |
|---|---|
| 4.6 | `fig_evolucion_NIV_EDUM` |
| 4.7 | `fig_evolucion_SEG_SOCIAL` |
| 4.8 | `fig_evolucion_EST_CIVM` |
| 4.9 | `fig_evolucion_AREA_RES` |

Van **apaisadas** (`landscape`) porque la relación de aspecto es 3,3:1 y en vertical el
recuadro de códigos resultaba ilegible. Se escalan con
`\makebox[\textwidth][c]{\includegraphics[width=1.40\textwidth]{...}}`: dentro de `pdflscape`
la página rota pero `\textwidth` no cambia, de modo que `width=\linewidth` dejaba la figura a
dos tercios del ancho aprovechable. El factor 1,40 es la razón entre el ancho útil de la
página rotada (22,9 cm) y `\textwidth` (16,1 cm).

El bloque se sitúa **al final de la subsección**, no inmediatamente tras el párrafo que las
anuncia. `landscape` fuerza salto de página, y colocarlo antes dejaba una página casi vacía
---tres líneas de texto y el resto en blanco.

## Problema que queda abierto y conviene resolver

Aun a ancho máximo, **el recuadro de códigos queda en torno a 4 pt**, por debajo del mínimo
legible en impresión. Hay un `\pendiente` con las dos salidas posibles. La recomendada es
suprimir el recuadro de la imagen y recoger las equivalencias en un **cuadro de LaTeX**: el
contenido de ese recuadro es una tabla, no un gráfico, y como cuadro entraría además en el
índice de cuadros.

## Orden de las figuras del Capítulo 4

Las figuras de la serie **armonizada** (4.2–4.4) aparecen **antes** que las de la serie
**original** (4.6–4.9), porque la sección de armonización precede en el capítulo a la
discusión de la ruptura. Narrativamente convendría el orden inverso: primero el diagnóstico,
después la corrección. No se reordenó porque exige mover secciones enteras del capítulo, y esa
es una decisión de estructura que corresponde al autor.

## Estado de compilación

```
0 errores · 0 citas sin resolver · 0 referencias sin resolver · 127 páginas · 20 figuras
```

---

# v33 · Las figuras vuelven a vertical, con cuadros y explicación

## Se retiró el bloque apaisado

Las cuatro figuras de evolución por código (4.6 a 4.9) estaban en páginas horizontales.
Se deshizo por tres razones: obliga al lector a girar el documento, el salto de página que
fuerza `landscape` dejaba media hoja en blanco, y aun a ancho completo el recuadro de códigos
quedaba en 4 pt.

**La solución fue quitar el recuadro de la imagen**, no agrandar la página. Cada figura se
inserta con `trim=16 0 312 0,clip`, que suprime el tercer panel —el de la leyenda— y deja los
dos paneles de datos. La relación de aspecto pasa de 3,3:1 a 2,5:1 y entra en vertical a
`\textwidth` sin apretar nada.

## El recuadro pasa a ser cuadro de LaTeX

Tres cuadros nuevos con la equivalencia de códigos entre las dos versiones del certificado,
transcritos **directamente de `src/etiquetas.py`**, no de la imagen:

| Cuadro | Variable |
|---|---|
| 4.12 | `NIV_EDUM` — 14 códigos |
| 4.13 | `SEG_SOCIAL` — 7 códigos |
| 4.14 | `EST_CIVM` — 7 códigos |

Ganancia triple: se leen, entran en el índice de cuadros, y la figura recupera el ancho que
ocupaba el recuadro. Los códigos que cambian de significado van en negrita.

## Explicaciones para el lector

Antes del bloque va un párrafo **«Cómo se leen las cuatro figuras que siguen»**: qué hay en
cada panel, qué es el eje vertical de cada uno, qué significan las bandas apiladas, qué son
las etiquetas del margen derecho, y por qué el eje es el **código original** y no la categoría
armonizada.

Después de cada figura va su lectura:

- **NIV\_EDUM** — el código 9 pasa de *sin información* a *profesional*. Una limpieza uniforme
  que tratase el nueve como faltante borraría del análisis a las madres con formación
  universitaria completa desde 2008, es decir, el extremo superior del gradiente educativo
  que es el objeto de la tesis. El código 8 invierte el problema: de *ninguno* a *tecnológica*.
- **SEG\_SOCIAL** — el grupo *no asegurado*, el extremo desfavorecido, solo existe como tal
  desde 2008.
- **EST\_CIVM** — renumeración completa; el código 1 pasa del 15,1 % al 50,8 % sin que cambie
  el comportamiento de la población.
- **AREA\_RES** — se incluye **como contraste**: es la única de las cuatro que conserva la
  codificación, y sus bandas no presentan discontinuidad. Si el corte de las otras tres fuera
  un cambio real de la población, aparecería también aquí.

Esa última figura era la más floja del bloque y ahora es la que cierra el argumento.

## Cambios en el código del análisis

`src/graficos.py` gana dos funciones:

- **`eje_de_anios(ax, anios, cada=2)`** — una marca por año, rótulo cada dos, girado 90°.
  Matplotlib dejaba `2000, 2005, 2010, 2015, 2020`: en una tesis cuyo hallazgo metodológico es
  una ruptura en **2008**, ese año ni siquiera aparecía escrito. También corrige la etiqueta
  del eje, que decía «Ano».
- **`marcar_ruptura(ax, 2008)`** — línea vertical discontinua del cambio de instrumento.

**Las figuras ya generadas no cambian solas.** Hay que volver a correr los notebooks para que
incorporen el eje corregido.

## Reglas añadidas a la skill `analisis-bpn-vscode`

Dos secciones nuevas, para que esto no se repita:

- **«La regla del eje temporal»** — todo gráfico con tiempo en el eje horizontal rotula los
  años; si la serie cruza 2008, dibuja la línea de ruptura.
- **«Cómo entra una figura en el manuscrito»** — seis reglas: ninguna figura sin párrafo
  explicativo antes y lectura después; nada de páginas apaisadas; el recuadro de leyenda se
  convierte en cuadro de LaTeX; pie corto para el índice; nombres de archivo sin eñes ni
  tildes; y comprobar que dos paneles que se comparan comparten escala.

Se añadieron además a la sección de coherencia los puntos de M0–M4 y la ausencia de IPM.

## Estado de compilación

```
0 errores · 0 citas sin resolver · 0 referencias sin resolver · 126 páginas
20 figuras · 0 páginas apaisadas
```

---

# v34 · Explicaciones de las figuras de desigualdad, y un pie de figura que era falso

## Error mío corregido: el pie de la Figura 5.10

La versión anterior afirmaba:

> «La coincidencia del año en que la serie cruza el cero con ambos ordenamientos indica que
> la inversión observada es un rasgo del fenómeno y no del instrumento de medida.»

**Eso es falso y la propia figura lo desmiente.** Comprobado en
`serie_anual_aseguramiento.csv`: el índice de Erreygers con ordenamiento por aseguramiento
permanece **positivo los veintisiete años**, en una banda de $+0{,}0032$ a $+0{,}0089$, y no
se aproxima al cero en ningún momento. Solo el ordenamiento educativo cruza.

El pie se reescribió en términos descriptivos y se añadió la lectura honesta:

> La inversión del gradiente es una propiedad del ordenamiento **educativo**, no una propiedad
> general de la desigualdad socioeconómica. «La desigualdad socioeconómica se invirtió en
> Colombia» no se sostiene; «el gradiente educativo se invirtió mientras el de aseguramiento
> se mantuvo» sí.

Queda un `\pendiente` con la explicación candidata ---dilución de la escala educativa por la
expansión de la cobertura--- marcada como pendiente de contraste, no como hallazgo.

## Figuras regeneradas desde las tablas de salida

`fig_serie_anual_desigualdad` y `fig_comparacion_ordenamientos` se rehicieron a partir de
`serie_anual_desigualdad.csv` y `serie_anual_aseguramiento.csv`, sin tocar los microdatos.
Cambios:

- **Eje de años rotulado**: marca en cada uno de los 27 años, rótulo cada dos, girado 90°.
  Antes matplotlib dejaba cinco marcas y el año del cruce no aparecía escrito.
- «Ano» pasa a **«Año de ocurrencia»**.
- Se retiró el título interno, que duplicaba el pie.
- En la comparación de ordenamientos, la anotación ahora dice **«cruce del cero solo en
  educación»**, que es lo que los datos muestran.

## Explicaciones incorporadas

**§5.3.4** — párrafo «Cómo se lee esta figura»: qué hay en cada panel, y sobre todo qué
significa el **signo** del índice. Naranja: el desenlace se concentra en las madres de mayor
educación. Azul: en las de menor educación. El cero no es ausencia de diferencias sino
ausencia de gradiente. Sin esa aclaración la figura es ilegible para quien no trabaje con
índices de concentración.

**§5.7** — subsección nueva «Especificación alternativa de la variable de ordenamiento», con
su párrafo de lectura y el criterio explícito: si las dos series coinciden, el resultado es
del fenómeno; si divergen, es en parte del instrumento. Divergen.

## Estado de compilación

```
0 errores · 0 citas sin resolver · 0 referencias sin resolver · 129 páginas
```

---

# v35 · Todas las figuras con explicación y ancladas a su texto

## El problema de fondo era de colocación, no de contenido

La explicación de la Figura 5.9 existía desde la v34, pero el flotante `[!htbp]` la empujaba a
otra página y la figura aparecía sola. Todas las figuras de los Capítulos 4 y 5 pasan a
`[H]`, que las fija donde están escritas. Deja algún hueco al final de página, pero garantiza
que figura y explicación nunca se separan, que es lo que importa aquí.

## Explicaciones nuevas

Cada figura tiene ahora su párrafo «cómo se lee», dirigido al lector:

| Figura | Qué explica el párrafo |
|---|---|
| 5.5 · matriz $V$ de Cramér | escala 0–1, qué buscar fuera de la diagonal |
| 5.6 · matriz de interacción | sinergia (rojo) frente a redundancia (azul), y por qué no es lo mismo que la 5.5 |
| 5.7 · curva de concentración | la diagonal es la igualdad; por encima / por debajo; el índice es el doble del área |
| 5.8 · índice de la pendiente | qué es el rango fraccional y qué aporta frente al índice de concentración |
| 5.9 · serie anual | qué significa el **signo**: naranja mayor educación, azul menor; el cero es ausencia de gradiente, no de diferencias |
| 5.10 · ordenamientos | el criterio explícito: si coinciden es del fenómeno, si divergen es del instrumento |

## Figura 5.9 regenerada otra vez

- **Eje de años en los dos paneles.** Antes `sharex` lo ocultaba en el panel superior, que es
  justamente el que se lee.
- **Valores anotados** en los tres puntos que cita el texto: $+0{,}00123$ (1998),
  $+0{,}00726$ (2009), $-0{,}00651$ (2024); y $7{,}60$ % y $11{,}11$ % en el panel inferior.
- Títulos por panel: «Desigualdad educativa» y «Nivel general de riesgo».
- La leyenda dice ahora «Positivo: se concentra en...» / «Negativo: se concentra en...», que
  es lo que hay que entender para leer la figura.

## Estado de compilación

```
0 errores · 0 citas sin resolver · 0 referencias sin resolver
130 páginas · 20 figuras · 21 cuadros · 0 páginas apaisadas
```

## Lo que sigue pendiente

- Redactar las lecturas marcadas con `\pendiente` (35 en el Capítulo 5).
- Ejecutar M2, M3 y M4; construir las Fases 5 y 7.
- Regenerar el resto de figuras del EDA con `eje_de_anios()` corriendo los notebooks.
- Verificar `manski1990` en JSTOR.


---

# v36 · Las explicaciones pasan de «qué es» a «qué aporta»

## El cambio

Los párrafos previos a cada figura describían el mecanismo de lectura: qué eje es cuál, qué
significa cada color. Correcto pero insuficiente: dejaban al lector sin saber por qué la figura
está en la tesis. Se reescribieron los siete para responder a la pregunta que importa, y cada
uno se ancla ahora en el **objetivo específico** al que sirve.

| Figura | Antes | Ahora |
|---|---|---|
| 4.6–4.9 | qué hay en cada panel | cuantifican cuánta población quedaría mal clasificada; sostienen la decisión de armonizar, que condiciona todo el Cap. 5 |
| 5.5 · $V$ de Cramér | escala 0–1 | el OE3 exige efectos **independientes**; la matriz verifica que sean separables. Sostiene conservar los cuatro determinantes en vez de un índice compuesto, y anticipa la limitación del efecto étnico |
| 5.6 · interacción | rojo sinergia, azul redundancia | el OE4 descompone de forma **aditiva**; lo que vive en la interacción queda repartido entre los efectos principales. Desventaja social y acceso deficiente no se suman: se refuerzan |
| 5.7 · curva | la diagonal es la igualdad | dos distribuciones distintas dan el mismo índice. La curva distingue gradiente sostenido de grupo atípico, y eso decide qué se puede afirmar |
| 5.8 · SII | qué es el rango fraccional | el índice de concentración no tiene unidades interpretables; el SII sí, y se traduce a número de nacimientos. Además pondera por población, decisivo en 27 años de expansión educativa |
| 5.9 · serie anual | qué significa el signo | el OE1 pide **tendencia**, que la cifra agregada oculta. Y contrapone desigualdad con nivel de riesgo: si la brecha se estrecha porque el riesgo sube en todos, es empeoramiento, no mejora |
| 5.10 · ordenamientos | criterio de lectura | el OE2 fija dos ejes; esta figura decide si el hallazgo se enuncia como «la desigualdad socioeconómica se invirtió» o solo como «el gradiente educativo se invirtió» |

La descripción del mecanismo se conserva donde sin ella la figura es ilegible ---el signo del
índice en la 5.9, la estructura de paneles en las 4.6–4.9--- pero pasa a segundo plano.

## Advertencia sobre la autoría de estos párrafos

Son **argumentación**, no descripción técnica. Reescríbelos con tus palabras antes de entregar:
son los pasajes que el jurado usará para comprobar que entiendes por qué cada figura está donde
está, y conviene que las frases sean tuyas.

## Estado de compilación

```
0 errores · 0 citas sin resolver · 0 referencias sin resolver · 131 páginas
```

---

# v37 · Mapas interactivos enlazados, y anotaciones en la Figura 5.10

## Los mapas ya se comparten con un clic

El Apéndice A.3 pasa de listar nombres de archivo a ofrecer **tres enlaces clicables** más un
**código QR** para la versión impresa. El QR está en `figuras/qr_mapas.png`.

**Por qué GitHub Pages y no otra cosa**, que era la pregunta:

| Opción | Veredicto |
|---|---|
| **GitHub Pages** | **elegida.** Gratis, permanente, el HTML se **renderiza** al abrirlo, y el repositorio ya existe y es público |
| Enlace directo al archivo en GitHub | no sirve: GitHub no renderiza HTML, lo descarga o muestra el código fuente |
| `htmlpreview.github.io` | funciona, pero depende de un servicio de terceros que puede desaparecer |
| Zenodo | da DOI permanente y citable, pero entrega un zip: hay que descargar y descomprimir |
| Incrustar el HTML en el PDF | descartado: un PDF no ejecuta JavaScript, y el material incrustado depende del lector |

Zenodo queda como alternativa documentada en el `\pendiente`, por si se prefiere no activar
Pages.

**Los enlaces todavía no resuelven.** El repositorio existe y es público, pero no tiene la
carpeta de mapas ni Pages activado. Las direcciones se escribieron con la forma que tendrán
—`gregorymelendez.github.io/TESIS-GRADO-UNINORTE-/`— y el `\pendiente` detalla los tres pasos
para activarlas. **Comprobar que los tres enlaces abren antes de entregar.**

Detalle de formato: el preámbulo usa `hidelinks`, de modo que los enlaces no se distinguían del
texto. Se definió el color `enlace` y se aplica solo a estos tres, para que el lector vea que
puede pulsarlos sin alterar el aspecto de las referencias cruzadas del resto del documento.

Se mantiene la frase que protege el documento: **ningún resultado defendido depende de
consultarlos**. Si el jurado no los abre, la tesis sigue en pie.

## Figura 5.10

Las etiquetas de años ya estaban desde la v34 —la captura que las echaba en falta estaba
recortada por abajo—, pero la figura se rehizo para que el argumento se lea sin recurrir al
texto:

- Anotada la **banda del aseguramiento**: +0,0032 a +0,0089 en 27 años.
- Anotados los dos valores de 2024: −0,00651 educación, +0,00636 aseguramiento.
- La nota roja dice ahora, completa: «la serie educativa cruza el cero en 2018–2019; la de
  aseguramiento, nunca».

## Estado de compilación

```
0 errores · 0 citas sin resolver · 0 referencias sin resolver · 132 páginas
```

---

# v38 · Atlas interactivo: los tres HTML en una sola página

## Qué se construyó

`atlas_bpn.html` (3,5 MB) reúne los tres mapas en **una sola página con pestañas**, con
cabecera de la tesis, créditos y nota metodológica. Está en
`CODIGO_VSC/salidas/mapas/atlas_bpn.html`.

Detalles técnicos de la fusión: los tres archivos de Plotly traían cada uno su propia etiqueta
del CDN; el atlas la carga **una sola vez** y reutiliza los identificadores de los `div`, que ya
eran únicos. Al cambiar de pestaña se llama a `Plotly.Plots.resize()`, porque un gráfico de
Plotly creado dentro de un contenedor oculto no calcula bien su ancho.

El atlas incorpora además, en el pie, la advertencia que los mapas impresos no pueden llevar:
la prevalencia de municipios con pocos nacimientos es inestable y los extremos pueden reflejar
tamaño de muestra y no riesgo. Es la misma advertencia que queda pendiente de redactar en
§5.1.5.

## Por qué el atlas no se publicó como artefacto de Cowork

Se evaluó y se descartó: el entorno de artefactos solo permite cargar Chart.js, Grid.js y
Mermaid desde CDN, y estos mapas son **Plotly**. Incrustar la biblioteca completa habría llevado
el archivo a unos 8 MB. GitHub Pages no tiene esa restricción y además da una dirección propia,
que es lo que hace falta para el QR.

## El apéndice pasa de tres enlaces a uno

A.3 se reescribió: una sola dirección ---la raíz del sitio--- y la descripción de las tres
vistas que contiene. Ventaja para el QR: apunta a la raíz, de modo que **no hay que
regenerarlo** cuando se publique.

## Lo que falta para que el QR funcione

El QR y el enlace **todavía no resuelven**. Tres pasos, en el `\pendiente` del apéndice:

1. Subir `atlas_bpn.html` a la raíz del repositorio con el nombre **`index.html`**.
2. *Settings* → *Pages* → *Source: Deploy from a branch*, rama `main`, carpeta `/ (root)`.
3. Esperar unos minutos y abrir `https://gregorymelendez.github.io/TESIS-GRADO-UNINORTE-/`.

**Comprobar que abre antes de entregar.** Un QR impreso que no lleva a ninguna parte es peor
que no poner QR.

## Estado de compilación

```
0 errores · 0 citas sin resolver · 0 referencias sin resolver · 133 páginas
```

---

# v39 · Se cierran los huecos de las páginas 85–86

## Qué los causaba

La v35 fijó todas las figuras con `[H]`, que prohíbe a LaTeX moverlas. Resolvió el problema de
que figura y explicación quedaran separadas, pero creó otro: cuando una figura alta no cabía en
lo que restaba de página, LaTeX no podía rellenar el hueco con el texto siguiente y dejaba media
hoja en blanco. Es lo que ocurría en las páginas 85 y 86.

## Cómo se corrigió

**Las catorce figuras pasan de `[H]` a `[!ht]`.** La diferencia importa: `[!ht]` permite a
LaTeX desplazar la figura lo justo para cerrar el hueco, pero al excluir `b` y `p` le impide
mandarla al pie de página o a una página de flotantes al final del capítulo, que era el
comportamiento del `[!htbp]` original. Figura y explicación siguen juntas; el hueco desaparece.

**La Figura 5.9 se rehízo más compacta**: de 8,4 × 7,4 a 8,2 × 5,6 pulgadas, con `sharex`
recuperado y cuerpos de letra menores. Era la figura que no cabía y la que empujaba al resto.
Conserva las anotaciones de valores y el eje de años en el panel inferior.

Resultado: el documento pasa de **133 a 131 páginas**. Esas dos páginas eran el espacio
desperdiciado.

## Recuento de páginas con poco texto

Quedan seis, todas legítimas: cuatro aperturas de capítulo y dos páginas ocupadas casi por
completo por una figura. Ninguna en blanco.

## Regla añadida a la skill

La sección «Cómo entra una figura en el manuscrito» recoge ahora este equilibrio, para no
repetir el ciclo: `[!ht]` como opción por defecto, nunca `[H]` ni `[!htbp]`.

## Estado de compilación

```
0 errores · 0 citas sin resolver · 0 referencias sin resolver · 131 páginas
20 figuras · 21 cuadros · 0 páginas apaisadas · 0 páginas en blanco
```

---

# v41 · La explicación pasa a ir debajo de cada figura

Los siete párrafos «Qué aporta…» estaban **antes** de su figura, de modo que el lector leía la
explicación de algo que todavía no había visto y, cuando el flotante se desplazaba un poco, el
párrafo quedaba a distancia del gráfico al que se refería. El orden pasa a ser:

```
figura  ->  pie de figura  ->  explicación
```

Seis bloques reordenados en el Capítulo 5 (figuras 5.5 a 5.10) y uno en el Capítulo 4.

**Caso particular del Capítulo 4.** El párrafo de las figuras 4.6–4.9 cubre las cuatro a la
vez, así que no podía ir debajo de la primera: se colocó **después de la última** y se
reescribió en consecuencia ---«Qué aportan estas cuatro figuras», no «las que siguen»---, de
manera que cierra el bloque en lugar de abrirlo.

## Regla añadida a la skill

«Cómo entra una figura en el manuscrito», punto 1: la explicación va **debajo** de la figura.
El pie ya la anuncia; un párrafo previo obliga a leer sobre algo que aún no se ha visto.

## Estado de compilación

```
0 errores · 0 citas sin resolver · 0 referencias sin resolver · 132 páginas
```

---

# v42 · Las figuras dejan de adelantar a su explicación

## El error que señaló la lectura de §5.2

En el archivo fuente el orden era correcto ---figura 5.5, su explicación, figura 5.6, su
explicación--- pero en el PDF las dos matrices salían **después** de ambos párrafos. El lector
se encontraba con dos bloques de texto seguidos, cada uno remitiendo a una figura que aún no
había aparecido, y el segundo empezando igual que el primero. Confuso, y con razón.

La causa es `[!ht]`: permite a LaTeX desplazar el flotante hacia adelante cuando no cabe, y
ambas matrices eran altas. `[!ht]` había sido la solución al problema de los huecos de la v39,
pero abre este otro.

## Cómo se resuelve sin reabrir el problema de los huecos

Las dos cosas son la misma tensión: un flotante grande no cabe donde se le pide, y hay que
elegir entre moverlo (se separa del texto) o dejarlo (queda un hueco). La salida no es elegir
entre las dos: es **que la figura quepa**.

1. Todas las figuras vuelven a `[H]`, que prohíbe el desplazamiento. Figura, pie y explicación
   quedan siempre juntos y en ese orden.
2. Las cinco figuras que no cabían se reducen:

```
fig_matriz_v_cramer                 0,92 -> 0,70 del ancho de texto
fig_matriz_interaccion              0,88 -> 0,68
fig_curva_concentracion_educacion   0,72 -> 0,62
fig_serie_anual_desigualdad         0,94 -> 0,86
fig_sii_educacion                   0,92 -> 0,86
```

El criterio: ninguna figura debe pasar de la mitad de la altura del bloque de texto. Por encima
de eso, `[H]` produce huecos.

## Comprobación

Páginas con diez líneas de texto o menos: siete, todas legítimas ---cuatro aperturas de
capítulo y tres ocupadas casi enteras por figuras a doble panel. Ninguna en blanco, y ninguna
figura por delante de su explicación.

## Regla añadida a la skill

Punto 7 de «Cómo entra una figura en el manuscrito»: `[H]` siempre, y la figura dimensionada
para que quepa en media página. Si no cabe, se reduce la figura; no se cambia la política de
flotantes.

## Estado de compilación

```
0 errores · 0 citas sin resolver · 0 referencias sin resolver · 133 páginas
```

---

# v43 · Redactada la lectura de los mapas (§5.1.5)

Tres marcas rojas sustituidas por texto. **Todas las cifras verificadas ejecutando sobre
`prevalencia_municipal_anual.parquet` y `cambios_de_posicion_departamentos.csv`**, no deducidas
mirando los mapas.

## Las tres observaciones

**Ascenso general.** El rango departamental pasa de 4,10–11,48 % en 1998 a 5,18–16,89 % en 2024.
Sube el máximo **y también el mínimo**, de modo que el incremento no procede de unos pocos
departamentos.

**Los territorios con valores altos cambian.** Bogotá encabeza en ambos años, pero el resto del
grupo se renueva por completo:

```
Chocó         2º -> 8º     10,19 -> 11,21 %
Cundinamarca  9º -> 2º      7,32 -> 14,51 %   (+7 posiciones)
Nariño       14º -> 3º      6,85 -> 13,14 %   (+11)
Caldas       23º -> 4º      6,15 -> 11,97 %   (+19)
```

Guainía, Guaviare y Vichada salen de las cinco primeras posiciones. El patrón territorial **se
reordena**, no se mantiene.

**La dispersión municipal supera a la departamental.** Desviación típica de la prevalencia:

```
1998   municipios 5,16 pp   departamentos 1,57 pp   (3,3x)
2024   municipios 13,97 pp  departamentos 2,59 pp   (5,4x)
```

La heterogeneidad vive **dentro** de los departamentos. Justifica los dos niveles y anticipa el
Modelo 0.

## La advertencia, ahora con cifras

Era una nota genérica; ahora tiene números, y son contundentes:

```
2024: 766 de 930 municipios (82,4 %) con menos de 100 nacimientos
      esos 766 reúnen solo el 2,84 % de los nacimientos del país
      rango municipal del año: 0 a 100 %
      383 municipios con prevalencia nula: TODOS con menos de 100 nacimientos
```

Un municipio al 100 % de prevalencia es la demostración de que el mapa no puede leerse como
riesgo. Se añade la explicación de la contracción: el intercepto aleatorio de un municipio con
pocos nacimientos se aproxima a la media departamental, y una coropleta no hace eso. Cierra
declarando que **el patrón que el trabajo sostiene es el de los modelos, no el de los mapas**.

## Nota retirada del manuscrito

La marca sobre el `trim` de los mapas era una nota de producción, no una tarea de redacción:
no pinta nada en el documento. Queda registrada aquí (v31) y se elimina del Capítulo 5.

## Recuento

Marcas `\pendiente`: de 48 a **45**. Queda una nueva en esta subsección, de decisión y no de
redacción: si el cuadro con el ordenamiento completo de los 33 departamentos va en el capítulo
o en un apéndice.

## Estado de compilación

```
0 errores · 0 citas sin resolver · 0 referencias sin resolver · 133 páginas
```

---

# v44 · Redactada la lectura de la serie anual (§5.3.4)

Tres marcas rojas sustituidas por texto, con las cifras de `serie_anual_desigualdad.csv`.

## Lo que se escribió

**Trayectoria en dos tramos.** El índice **asciende** de 1998 a 2009 ($+0{,}00123 \to
+0{,}00726$) y desciende desde ahí, cruza el cero en 2019 y termina en $-0{,}00651$ en 2024.
El SII recorre el mismo camino: de $+1{,}40$ pp en 2009 a $-1{,}26$ en 2024. El RII, de
$1{,}169$ a $0{,}893$.

Detalle que no estaba en la nota y que refuerza el hallazgo: **la primera década el índice sube,
no baja**. No es una brecha que se estrecha desde el principio, sino una que primero se abre y
luego se invierte.

**El cruce no es un episodio de un año.** Los seis últimos años ---2019 a 2024--- tienen índice
negativo, y la magnitud crece de forma monótona desde 2021. Eso lo blinda frente a la objeción
de que podría ser ruido de un año concreto.

**La lectura benévola queda excluida explícitamente**, porque es la que el lector hace por
defecto: lo observado no es que el grupo desfavorecido haya mejorado hasta alcanzar al
favorecido, sino que el riesgo subió en ambos y más deprisa en el desfavorecido. La prevalencia
global pasa de 7,60 a 11,11 % en el mismo período.

**Alcance.** Párrafo propio que remite a §5.7.1 y enuncia el resultado como propiedad del
gradiente **educativo**, no de la desigualdad socioeconómica en general.

## La nota que se conserva, reformulada

«Decidir cuánto peso darle» era vaga. Se sustituye por una decisión concreta y argumentada por
las dos partes: si el resultado se presenta como **el** hallazgo principal ---a favor: ningún
trabajo previo sobre BPN en Colombia lo ha documentado--- o como uno entre varios ---a favor:
depende de la variable de ordenamiento, y la explicación de por qué depende no está contrastada.
Es una decisión para el director, no para el redactor.

## Recuento

Marcas `\pendiente`: de 45 a **43**.

## Estado de compilación

```
0 errores · 0 citas sin resolver · 0 referencias sin resolver · 134 páginas
```

---

# v45 · Las 43 notas rojas se reescriben en primera persona

Estaban redactadas como instrucciones de un tercero al autor ---«reescribe con tus palabras»,
«conviene que digas»---, lo que resulta incómodo en un archivo que firma el autor. Pasan a ser
**notas suyas para sí mismo**, con encabezados que dicen de qué tipo es cada una:

```
NO OLVIDAR / ME FALTA / PENDIENTE MÍO / DECISIÓN MÍA
DECISIÓN PARA HABLAR CON LIHKI / MI HIPÓTESIS
YA TENGO ESTAS CIFRAS / ESTADO DEL CAPÍTULO
MEJORA QUE QUIERO HACER / ANTES DE ENTREGAR
```

Así, de un vistazo se distingue lo que falta ejecutar de lo que solo falta redactar, y lo que
se decide solo de lo que hay que consultar con el director.

Tres se reformularon a fondo porque eran vagas:

- La del cruce del gradiente pasa a ser una decisión con los argumentos de ambas partes.
- La de la dilución de la escala educativa queda marcada como **hipótesis sin contrastar**, con
  la advertencia de que es la primera pregunta que va a recibir.
- La del atlas abre con «ANTES DE ENTREGAR, imprescindible», que es su prioridad real.

El archivo `PENDIENTES_manuscrito.md` se regeneró con los textos nuevos.

## Estado de compilación

```
0 errores · 0 citas sin resolver · 0 referencias sin resolver · 134 páginas · 43 notas
```

---

# v46 · «Mis pendientes»: la lista vive dentro del manuscrito

## Qué se añadió

Un capítulo sin numerar al final del documento, después de la bibliografía, que recoge **las 43
notas con el número de página donde está cada una**. Entra en el índice general.

Lo importante es que **no se escribe a mano: se genera sola**. Cada `\pendiente{...}` hace dos
cosas a la vez: sale en rojo donde está, y se apunta en la lista. Es imposible que las dos
versiones se desincronicen, y cada nota que se borre del texto desaparece de la lista en la
compilación siguiente.

## Cómo está hecho

`\pendiente` escribe en un archivo auxiliar `main.pnd` con `\protected@write`, que aplaza la
escritura hasta que la página se compone: así el número registrado es la página real y no la
siguiente. La lista **cierra el archivo antes de leerlo**, de modo que refleja la compilación en
curso y no la anterior --- que es el problema habitual de este tipo de listas.

## Dos tropiezos que conviene dejar anotados

1. **`\addcontentsline` con `\@starttoc` no sirve para una lista al final.** El flujo de
   escritura solo existe desde que `\@starttoc` se ejecuta; si está al final, todas las
   anotaciones del cuerpo se pierden. Hubo que gestionar el `\newwrite` a mano.
2. **`\pendiente` tiene que definirse DENTRO de `\makeatletter`.** Fuera, la arroba de
   `\@anotarpendiente` no es letra y LaTeX lo lee como `\@` seguido de texto: **no da error**,
   simplemente no escribe nada. Costó una compilación entera de diagnóstico.

## Modo limpio

Sigue siendo una línea. En `preambulo.tex`, descomentar:

```latex
\renewcommand{\pendiente}[1]{}
\renewcommand{\listadependientes}{}
```

Desaparecen las notas del texto **y** el capítulo de la lista.

## Estado de compilación

```
0 errores · 0 citas sin resolver · 0 referencias sin resolver
138 páginas · 43 notas listadas · 20 figuras · 21 cuadros
```

---

# v47 · §5.5 con los resultados reales de la Fase 5

## El hallazgo, y no es el que esperaba

La educación **no** es el principal contribuyente a la desigualdad educativa. Índice del
período $+0{,}0182$, repartido así:

```
PARIDAD4      +0,01529   ( 84,1 %)   <- el mayor
SEG4          +0,00696   ( 38,3 %)
AREA_RES      +0,00410   ( 22,5 %)
ESTCIV5       -0,00447   (-24,6 %)
EDUC4_MADRE   -0,00343   (-18,8 %)   <- en contra del signo del total
EDAD3         -0,00114   ( -6,3 %)
MULTIPLE3     +0,00088   (  4,9 %)
```

Ningún intervalo bootstrap cruza el cero.

**El mecanismo de la paridad.** Cuatro o más hijos se asocia con MENOS bajo peso al nacer
($\beta=-0{,}0285$) y se concentra en las madres menos educadas ($CI_k=-0{,}409$). Negativo
por negativo da positivo: la paridad alta protege al grupo desfavorecido y empuja el índice
hacia el extremo más educado. Coherente con la literatura clínica, donde la primiparidad es
factor de riesgo. **Falta la cita.**

## La inversión del gradiente queda explicada

Descomposición por tramos, contribuciones absolutas:

```
                1998-2009   2010-2018   2019-2024
EDUC4_MADRE      -0,00721    -0,01504    -0,02992     x4 en la direccion clasica
PARIDAD4         +0,01660    +0,01293    +0,01096     el contrapeso se debilita
indice del tramo +0,01682    +0,01052    -0,00385
```

La frase defendible: **el gradiente no se invirtió por cambio de composición demográfica, sino
porque la contribución propia de la educación se cuadruplicó mientras el contrapeso de la
paridad se debilitaba.** Una crece, la otra afloja, y el total cruza el cero.

**Esto descarta una hipótesis propia**, la de la dilución de la escala educativa que figuraba
en §5.7. Si la escala se hubiera diluido, la contribución de la educación se habría
debilitado; se cuadruplicó. Hay que retirarla de esa sección.

## Error mío, corregido

La primera versión del bloque de tramos comparaba **porcentajes** entre tramos. No sirve: el
porcentaje divide por el índice del tramo, y en 2019--2024 ese índice vale $0{,}0038$. Dividir
por una cantidad diminuta producía valores de $-777$\,\% y $+285$\,\% que no significan nada.
El notebook compara ahora contribuciones absolutas, con una línea que verifica que suman el
índice de su tramo. Los porcentajes se guardan aparte, con la advertencia de que solo sirven
dentro de un tramo.

## Lo que queda en §5.5

Ocho notas, todas de redacción y ninguna de ejecución: las cifras están. Se añadió el
Cuadro~\ref{tab:tramos} con las contribuciones por subperíodo y las dos figuras de la Fase 5.

## Hueco de reproducibilidad detectado en la Fase 4

El notebook 04 **imprime** las componentes de varianza de M0 ---$\sigma$ municipal y
departamental, CCI, MOR--- pero **no las guarda con `guardar_tabla`**. Son justamente las
cifras que el manuscrito cita en §5.4.1. No se parcheó todavía porque el notebook estaba
corriendo y modificar el `.ipynb` en caliente puede perder la sesión. **Pendiente para cuando
termine.**

## Estado de compilación

```
0 errores · 0 citas sin resolver · 0 referencias sin resolver
143 páginas · 49 notas
```

---

# v48 · La hipótesis de dilución se retira del texto, no solo de una nota

En la v47 quedó anotado que había que retirarla; ahora está hecho.

**§5.7 · «Una explicación que los datos descartan».** Párrafo nuevo, escrito en el orden que la
hace comprobable: primero la hipótesis, después qué predeciría, después qué se observa.

> Bajo la hipótesis de dilución, la contribución propia del nivel educativo debería
> **debilitarse** a lo largo del período. Lo observado es lo contrario: pasa de $-0{,}00721$
> a $-0{,}02992$, se multiplica por más de cuatro, y en la dirección del gradiente clásico.

Conclusión escrita en el texto: la divergencia entre los dos ordenamientos se debe a que miden
dimensiones distintas de la posición social, no a que uno se haya degradado como instrumento.

**La hipótesis se conserva, refutada, en lugar de borrarse.** Es de las pocas ocasiones de
mostrar una hipótesis propia puesta a prueba antes de que la ponga el jurado, y borrarla
desperdiciaría ese argumento.

**§5.3.4 · la decisión para el director, actualizada.** Ya no dice que la explicación «todavía
no está contrastada». Ahora: el argumento en contra por dilución **ya no vale**, y a favor de
presentarlo como hallazgo principal se suma que desde la Fase 5 hay mecanismo y no solo
observación.

**§5.5 · nota reducida.** Remite a §5.7 en lugar de repetir el argumento.

Notas del Capítulo 5: de 43 a **42**.

## Estado de compilación

```
0 errores · 0 citas sin resolver · 0 referencias sin resolver · 143 páginas
```

---

# v49 · §5.4 con M0 y M2 reales, y el hallazgo del ajuste obstétrico

## M0 verificado contra el manuscrito

`guardar_componentes_m0.py` cerró el hueco de reproducibilidad de la v47. Las cuatro cifras
que el manuscrito ya afirmaba **cuadran**:

```
sigma municipio      manuscrito 0,1772   obtenido 0,1772   OK
sigma departamento   manuscrito 0,1693   obtenido 0,1693   OK
CCI municipal        manuscrito 1,79 %   obtenido 1,7928   OK
MOR municipal        manuscrito 1,1840   obtenido 1,1841   OK
```

Añadidas al Cuadro 5.x: CCI departamental 0,86 %, MOR departamental 1,175, y la prevalencia
del municipio mediano (7,26 %) frente a la observada (8,78 %), cuya diferencia es el efecto
conocido de la no linealidad y no un error.

## El hallazgo de M2, que no esperaba

**El ajuste obstétrico no atenúa el gradiente educativo: lo ordena.**

```
             M1 (sin ajuste)   M2 (ajustado)   cambio
Primaria         0,857            0,854        -0,28 %
Secundaria       0,858            0,834        -2,73 %
Superior         0,874            0,808        -7,52 %
```

En M1 el gradiente sale **plano y desordenado** —superior con más riesgo que secundaria—. En
M2 sale **monótono descendente**, que es el gradiente social clásico. Las covariables
obstétricas estaban **enmascarándolo**.

Eso es lo contrario de lo que produce ajustar por un mediador, y confirma que edad, paridad y
multiplicidad actúan como confusores o covariables de precisión. Es un argumento que sostiene
la decisión de la Sección 4.4.4 con datos en lugar de con teoría.

## Comprobaciones que salieron bien

- **Edad materna en U**: 1,095 en menores de 20 y 1,385 en 35 o más, ambas sobre el tramo de
  20 a 34. Si no hubiera salido en U, habría un error en las referencias.
- **Multiplicidad**: RM de 19,96 en dobles y 23,07 en triples, coherente con la prevalencia
  observada del 59,15 % frente al 7,87 %. Es el efecto mayor de todo el trabajo y contribuye
  solo el 4,9 % a la desigualdad: el mejor ejemplo de que efecto y desigualdad son cosas
  distintas.

## Un resultado incómodo que hay que debatir

**«No asegurado» da 0,989**, prácticamente 1, mientras «subsidiado» da 1,073. El gradiente por
aseguramiento casi desaparece al ajustar y el grupo teóricamente más desfavorecido no muestra
mayor riesgo. Hipótesis a contrastar, anotada en el manuscrito: quien no está asegurado puede
tener menos probabilidad de que su parto quede registrado con peso informado. **Debatir con el
director antes de escribirlo.**

## Erratas de LaTeX corregidas

Una nota con una línea en blanco dentro rompe `\textcolor` ---«Paragraph ended before
\@textcolor was complete»---. Se juntó el párrafo y se añadió una comprobación que recorre
todas las notas buscando saltos de párrafo internos. Ahora son cero.

## Estado

```
0 errores · 0 citas sin resolver · 0 referencias sin resolver · 147 páginas · 54 notas
```

Faltan M3 y M4, que el notebook 04 sigue calculando.

---

# v50 · Revisión doctoral: correcciones aplicadas

Revisión sistemática de citas, referencias cruzadas, coherencia de conteos y tipografía. El
informe completo está en `REVISION_doctoral_v49.md`.

## Errores corregidos

**E1 · Etiqueta `sec:faltantes` definida dos veces**, en el Capítulo 3 y en el 4. LaTeX se
queda con la última y **no avisa**: toda remisión apuntaba al Capítulo 4. La del Capítulo 3
pasa a `sec:faltantes-teoria`. Se comprobó que las tres referencias existentes apuntaban
efectivamente a la del Capítulo 4, de modo que ninguna cambia de destino.

Es el segundo caso de este tipo ---el primero fue `sec:armonizacion` en la v30---, lo que
sugiere revisar las etiquetas cada vez que se añade una sección.

**E2 · «Soltera» aparecía como 1,287 y como 1,288.** El valor exacto es $1{,}287963$, luego
1,288 es el redondeo correcto y 1,287 un truncamiento. Unificado. Importa porque esa cifra
sostiene la comparación con la MOR municipal, que es el argumento más fuerte del capítulo.

**E3 · Cifras antiguas de M1.** Comprobado: ya no queda ninguna aparición de `0,855` ni
`0,872` en todo el documento. El error estaba resuelto sin saberlo.

## Inconsistencias corregidas

**I1 · `dnp2023ipm` estaba en el `.bib` sin citar.** En lugar de borrarla, se cita donde
corresponde: en §4.2.3, que justifica **por qué no** se usan indicadores municipales de
privación. Ahora esa justificación tiene fuente y la entrada deja de estar huérfana.
**Entradas sin citar: cero.**

**I2 · Veintidós cuadros sin declarar fuente.** Todas las figuras la llevaban; ningún cuadro.
Se asignó la fuente que corresponde a cada uno, distinguiendo tres orígenes:

| Origen | Fórmula | Casos |
|---|---|---|
| Transcripción del diccionario DANE | «Fuente: diccionarios de datos…» | códigos NIV\_EDUM, SEG\_SOCIAL, EST\_CIVM, PESO\_NAC |
| Resumen propio del diccionario | «Elaboración propia a partir de los diccionarios…» | ruptura semántica, variables nuevas y eliminadas |
| Resultado propio | «Elaboración propia a partir de los microdatos…» | M0, M2, tramos, flujo de la muestra |
| Simulación | «Elaboración propia a partir de datos simulados» | los cuatro del Apéndice B |

La distinción no es cosmética: transcribir el diccionario del DANE sin decirlo presenta como
elaboración propia algo que no lo es.

**I4 · La Fase 7 no declaraba a qué objetivo sirve.** Las demás secciones de resultados dicen
a qué pregunta específica responden; §5.6 no. Ahora declara que corresponde al segundo término
del **objetivo general** ---identificar los grupos en mayor riesgo--- y no a un objetivo
específico. Sin esa aclaración el lector busca la correspondencia y no la encuentra.

## Pendiente de decisión

**I3 y M3 · 76 etiquetas nunca referenciadas**, casi todas ecuaciones numeradas que el texto
no menciona. Hay que decidir si se remite a ellas o si se les quita la numeración. Es decisión
de autor, no corrección.

**M1 · Seis cajas desbordadas.** Antes de la entrega final.

**M2 · Las tablas del código no se insertan con `\input`.** Los cuadros del Capítulo 5 se
componen a mano con las cifras copiadas, que es de donde salen las incoherencias entre código
y manuscrito.

## Estado

```
0 errores · 0 citas sin resolver · 0 referencias sin resolver
0 etiquetas duplicadas · 0 entradas del bib sin citar · 0 cuadros sin fuente
148 páginas · 53 notas
```

---

# v51 · Las dos decisiones de la revisión doctoral, resueltas

## Ecuaciones: se citan, no se despromocionan

Había **13 ecuaciones numeradas** que ningún punto del texto mencionaba. Se optó por remitir a
ellas desde donde corresponde, que es más trabajo que quitarles el número pero conecta el
Capítulo 3 con el 4 y demuestra que la teoría sostiene el método en lugar de acompañarlo.

| Ecuación | Dónde se cita ahora |
|---|---|
| `eq:cramer` | §4.4.2, donde el $V$ de Cramér actúa como diagnóstico |
| `eq:entropia-shannon` | §4.4.2, la normalización por $H(Y)$ |
| `eq:woolf`, `eq:ic-woolf` | §4.4.4, razones de momios e intervalos |
| `eq:arbol-prediccion`, `eq:gboost`, `eq:mlp` | §4.4.7, al enumerar los siete modelos |
| `eq:entropia-nodo`, `eq:mse-nodo`, `eq:neurona` | §4.4.7, párrafo nuevo sobre el criterio de partición |
| `eq:rubin-punto`, `eq:rubin-varianza` | §4.3.6, reglas de combinación de Rubin |
| `eq:hessiano` | Apéndice B, que la definía sin referirse a ella |

Se añadió un párrafo en §4.4.7, **«Criterio de partición de los árboles»**, que explica cómo
se divide cada nodo y aclara que la versión para desenlace continuo figura en el marco teórico
solo para situar el procedimiento, no porque se emplee. Esa aclaración evita una pregunta.

**Ecuaciones etiquetadas: 34. Citadas: 34. Sin citar: ninguna.**

## Cuadros: cuerpo a mano, apéndice automático

**Apéndice C nuevo · «Resultados completos generados por el código».** Sus cuadros **no están
escritos a mano**: se insertan con `\input` desde `tablas/`, que son los archivos que producen
los notebooks. Al volver a correr el análisis cambian solos.

La lógica del arreglo: los cuadros del Capítulo 5 se componen para leerse ---nombres
traducidos, filas agrupadas, columnas auxiliares omitidas--- y esa edición abre la posibilidad
de que una cifra transcrita quede desactualizada. El Apéndice C es el contraste: cualquiera
puede comparar la cifra del cuerpo con la que produjo el código.

Incluye por ahora siete cuadros ---M0, M1, M2, efecto del ajuste, y los cuatro de la
descomposición---, con una nota para añadir los de M3, M4 y la Fase 7 cuando terminen.

Y una regla que queda escrita en el apéndice: **si un cuadro del Capítulo 5 dejara de coincidir
con el de aquí, manda el de aquí.**

## Estado

```
0 errores · 0 citas sin resolver · 0 referencias sin resolver
0 etiquetas duplicadas · 0 ecuaciones sin citar · 0 cuadros sin fuente
152 páginas
```

Queda solo M1 de la revisión: seis cajas desbordadas, cosmética para el final.

---

# v52 · Revisión doctoral sustantiva: corregidas las contradicciones texto–código

Segunda revisión, esta vez sobre las **junturas** y no sobre la forma. El informe completo está
en `REVISION_doctoral_sustantiva_v51.md`. Se corrigieron las cuatro contradicciones entre lo
que afirma el manuscrito y lo que ejecuta el código, más los dos supuestos sin declarar.

## C1 · «Únicamente la posición social» — la más seria

El resumen y §4.4.7 afirmaban predecir «a partir únicamente de la posición social de la
madre». El notebook entrena con `T_GES`, `MUL_PARTO`, `NUMCONSUL`… **Y la propia §4.4.7 lo
reconocía dos párrafos más abajo**, al explicar que los mediadores entran ahí legítimamente:
contradicción dentro de la misma subsección.

**No se resolvió cambiando solo el texto.** Se separaron las dos preguntas y se implementó la
segunda, que faltaba:

1. Cuánto predice el conjunto completo del certificado.
2. Cuánto predice **solo el bloque social**.

La diferencia mide el aporte predictivo propio de la posición social por encima de la
información clínica, que es la pregunta con contenido sustantivo. Bloque 6b nuevo en el
notebook 07 y en `fase7_portatil.py`, con dos tablas: `clasificacion_solo_social` y
`clasificacion_aporte_social`.

La celda de lectura deja escrito lo que hay que entender: que el bloque social prediga poco
**no contradice** que los determinantes sociales tengan efecto. Predecir y explicar son
objetivos distintos, y un factor puede ser causalmente relevante y predictivamente pobre.

## C2 · Bootstrap

El resumen decía «no paramétrico con 1.000 réplicas». La realidad: paramétrico sobre datos
agrupados en las Fases 3 y 5, no paramétrico sobre el conjunto de prueba en la 7. Corregido en
el resumen y en §4.4.7, **justificando por qué cada fase usa el que usa** en lugar de
limitarse a enumerarlo.

## C3 · Hiperparámetros

El texto describía validación cruzada anidada con búsqueda. El notebook los fija a mano.
Reescrito: se declaran los valores empleados, se justifica la decisión por viabilidad ---una
búsqueda multiplicaría el cómputo por veinte--- y se añade la implicación:

> Con hiperparámetros no optimizados, el desempeño de cada modelo es una **cota inferior**. Esa
> limitación afecta sobre todo a los ensambles y **juega en contra de la hipótesis de que la
> complejidad no aporta**: si aun así no superan a la logística, la conclusión se sostiene con
> mayor holgura.

El sesgo va en contra del resultado, y decirlo lo refuerza.

## C4 · Ponderación de clases

Se afirmaba de los siete. El perceptrón multicapa no la admite. Corregido a «seis de los
siete», con la explicación de que en el perceptrón el desbalance se compensa en el umbral ---lo
que además explica por qué su umbral óptimo ronda 0,12 y el de los demás 0,58.

## S1 · Constancia del efecto en veintisiete años

Los cinco ajustes estiman un coeficiente único para todo el período. **La Fase 5 demuestra que
el efecto cambia**: la contribución de la educación se cuadruplica. Declarado en §4.4.4: los
coeficientes son **promedios ponderados del período**, y la evolución se estima en la Fase 5.
Sin esa aclaración las dos fases parecen contradecirse.

## S2 · Dirección del sesgo por variables omitidas

Estaba como limitación genérica. Ahora declara la **dirección**: nutrición, exposición laboral
e hipertensión no controlada se distribuyen en contra de la población desfavorecida, de modo
que su ausencia **atenúa** el efecto social estimado. Los coeficientes son una **cota
inferior**, y el sesgo juega en contra de la hipótesis del trabajo.

## Regla que conviene recordar

Al corregir C1 estuve a punto de crear una contradicción nueva: prometer en el manuscrito las
dos especificaciones sin implementarlas. **Cuando el texto y el código discrepan, la corrección
completa cambia los dos**, no solo el que es más fácil de editar.

## Estado

```
0 errores · 0 citas sin resolver · 0 referencias sin resolver · 154 páginas
notebook 07: 45 celdas, probado de punta a punta
```

---

# v53 · Fuera el apaisado: ninguna página rotada en el documento

## El problema del número de página

En el Apéndice D ---el diccionario consolidado--- el número salía **impreso de canto** en una
esquina. Dentro de un bloque `landscape` todo gira con la página, encabezado incluido. Se probó
llevarlo al pie centrado y seguía saliendo rotado, solo que en otro sitio.

**La causa no era el número, era el apaisado.** Y ese apéndice era la única excepción que
quedaba a la regla ya fijada: si una tabla no cabe en vertical, el problema es la tabla.

## Qué se hizo

- Eliminado el bloque `landscape` del apéndice del diccionario.
- Columnas recalculadas para el ancho de texto vertical y cuerpo bajado a `\tiny`. La razón es
  concreta: los nombres largos del certificado ---`T_GES_AGRU_CIE`, `CODPAISNACMAD`,
  `IDFACTORRH`--- tienen catorce caracteres y en cuerpo mayor invadían la columna siguiente.
  Es una tabla de **consulta**, no de lectura seguida, de modo que aquí el cuerpo pequeño es
  aceptable. Distinto del recuadro de códigos de las figuras, donde 4 pt era inaceptable porque
  contenía el argumento.
- Retirado `pdflscape` del preámbulo y el estilo de página auxiliar, para no dejar código
  muerto.

## Las tablas del Apéndice C se salían del margen

Los `.tex` generados traen todas sus columnas y no caben en el ancho de texto: se veía
`pct_del_t…` cortado. Van ahora dentro de un `resizebox` al ancho de texto. Encogerlas es
preferible a recortarlas, porque ese apéndice existe justamente para reproducir la salida
íntegra.

## Estado

```
0 errores · 0 citas sin resolver · 0 referencias sin resolver
0 páginas rotadas · overfull: de 6 a 1
153 páginas
```

## v54 — 18 de septiembre de 2026

**Capítulo 5.** Redactados 16 de los 46 apartados que estaban en nota roja. Quedan 30.

Descriptivos y formales (10): Modelo 0 (CCI y varianza latente; nota al pie sobre por qué
el intercepto estima la mediana y no la media), Modelo 1, la U de la edad materna, la
multiplicidad, el reparto de la descomposición, el mecanismo de la paridad, el residuo cero
por construcción, elasticidad frente a distribución, y la nota sobre por qué las
contribuciones por tramo se reportan en valor absoluto.

Argumentativos (6): el ajuste obstétrico que ordena el gradiente, el aseguramiento con el
contraste de subregistro, el contraste MOR (versión breve en 5.4.1 y completa en 5.4.7), la
inversión del gradiente y la limitación de los tramos.

**Correcciones.** La frase del contraste MOR usaba 1,288, que es el valor de M1, en un
párrafo posterior a M2; se cambia a 1,257 y se nombra el modelo. Se añade
`\label{sec:res-contraste}`.

**Bibliografía.** Dos entradas nuevas verificadas: `shah2010paridad` (Acta Obstet Gynecol
Scand 89(7):862-875, DOI 10.3109/00016349.2010.486827), citada en el mecanismo de la
paridad; y `shah2011conyugal` (Matern Child Health J 15(7):1097-1109, DOI
10.1007/s10995-010-0654-z), **todavía sin citar**: falta decidir dónde.

**Resuelto: los dos valores del índice.** La Fase 3 estima +0,017404 sobre 16.820.098
registros, los que tienen nivel educativo informado. La descomposición estima +0,018182 sobre
15.946.216, los que tienen dato completo en los siete determinantes: 873.882 menos. La suma de
los tres tramos de `descomposicion_tramos_indice.csv` da exactamente 15.946.216, lo que
confirma la cifra. Queda declarado en nota al pie en 5.5, y ahí se dice que los porcentajes de
esa sección se calculan sobre +0,018182.

## v56 — 18 de septiembre de 2026

**Contraste MOR.** Pasa a usar la razón de momios mediana del Modelo 2 (1,197) en lugar de la
del Modelo 0 (1,184), de modo que las dos cantidades comparadas proceden de la misma
especificación. Se retira la advertencia sobre la falta de homogeneidad, que ya no aplica, y
se añade nota al pie explicando por qué la varianza entre municipios aumenta al incorporar los
determinantes individuales.

**M3 y M4 ya corrieron** (15 y 18 de septiembre). Los hallazgos y las decisiones pendientes
están en `HALLAZGOS_M3_M4.md`. Los tres que afectan al documento:

1. AIC y BIC NO son comparables entre modelos: la log-verosimilitud incluye la constante
   combinatoria de la binomial, que depende del número de celdas y este cambia con cada
   modelo. La Seccion 5.4.6 no puede escribirse hasta corregirlo. No exige reajustar.
2. La CCI municipal de M0 es 1,79 % si el denominador omite la varianza departamental y
   0,94 % si la incluye. Hay que decidir y unificar: afecta a 5.4.1, al resumen y a las
   conclusiones.
3. El coeficiente del aseguramiento pasa de 0,989 en el periodo completo a 1,109 restringido
   a 2008-2024. Decidir con Lihki cuál se reporta.

## v57 — 18 de septiembre de 2026

**Escritas 5.4.4, 5.4.5 y 5.4.6.** Del Capitulo 5 quedan 28 notas rojas; eran 46.

5.4.4 (etnia). Tres medidas independientes sostienen que la etnia no aporta por encima del
municipio: coeficientes entre 0,833 y 1,059, desplazamiento de los demas coeficientes por
debajo del 0,16 %, CPV municipal del -0,03 %, y AIC que empeora en 1,7. Se declara que el
coeficiente es una cota inferior y que el diseño no permite separar etnia de territorio.

5.4.5 (mediador). Se reporta la atenuacion del gradiente --hasta el 90,2 % en la categoria
superior-- y se declaran las tres razones por las que NO puede leerse como proporcion mediada:
las consultas dependen de la duracion de la gestacion, seis coeficientes cambian de signo, y
la varianza departamental se duplica.

5.4.6 (ajuste). Tablas de AIC/BIC y de CPV, solo entre modelos con la misma submuestra. Nota
al pie explicando por que los criterios se calculan sobre la log-verosimilitud sin agregar.
Falta la fila de M3b -> M4.

**Aseguramiento.** El parrafo de 5.4.3 ahora se apoya en el Modelo 2b (RM de 1,109 sobre
2008-2024) ademas de en el subregistro. El 72,1 % del grupo viene de antes de 2008, donde la
categoria mezcla vinculados y particulares y su prevalencia registrada (7,67 %) es inferior a
la del contributivo (8,31 %).

**Codigo.** `src/multinivel.py` guarda `coef_binomial` y `loglik_kernel`, y calcula AIC y BIC
descontando la constante. `fase7_portatil.py` corregido: `categorical_features` se fija con los
indices de columna en evaluar(), porque el valor "all" no lo aceptan las versiones recientes de
scikit-learn. Verificado de punta a punta con datos simulados.

## v58 — 18 de septiembre de 2026

**Escritas 5.1, 5.2 y 5.3.** Del Capitulo 5 quedan 21 notas rojas; eran 46 al empezar el dia.

5.1.1 Completitud por variable y anio, con los tres rasgos que condicionan el diseno: la
completitud mejora con el tiempo, la etnia es ausencia estructural antes de 2008, y los
controles prenatales son la variable peor informada (minimo del 69,6 %).

5.1.2 Prevalencia global del 8,78 % con intervalo de Wilson [8,77 ; 8,79], y la advertencia
de que mide precision sobre la prevalencia REGISTRADA.

5.1.3 Caracterizacion. Aqui esta el resultado que organiza el capitulo: la prevalencia NO
desciende al subir por la escala educativa. El minimo es primaria (8,16 %) y la educacion
superior (9,20 %) queda cerca de ninguna educacion (9,40 %). Con aseguramiento el ascenso si
es monotono: 8,36 -> 8,52 -> 9,27 %. De ahi se siguen el signo positivo del indice, el
gradiente plano de M1 y la plausibilidad de que el ajuste obstetrico lo reordene.

5.2 Cribado por informacion mutua. Catorce de quince variables superan su nulo; la
pertenencia etnica no lo supera (razon de 0,3). Se declara que el descarte solo aplica a la
Fase 7 y que la informacion mutua mide asociacion bruta: la edad gestacional concentra el
25,7 % de la entropia precisamente por estar en la via causal inmediata.

5.3 Prevalencia por posicion, indices con intervalos bootstrap (CI +0,0174, Erreygers
+0,0061, Wagstaff +0,0191) y SII/RII con su traduccion a unos 203.000 nacimientos, declarando
que esa cifra es un calculo y no un exceso evitable.

## v59 — 18 de septiembre de 2026

**Capitulo 5: quedan 13 notas rojas.** Nueve esperan a la Fase 7, una a la Fase 6, una a M3b,
una es la decision con Lihki y otra es la nota de estado.

**Nuevo analisis: regresion de puntos de union.** `puntos_de_union.py`. La serie sostiene TRES
puntos de union, en 2010, 2014 y 2020.

    1998-2010   +1,724 % anual
    2010-2014   -0,915 %        unico tramo de descenso
    2014-2020   +1,060 %
    2020-2024   +4,972 %        mas de cuatro veces el promedio

Se detecto sobredispersion: phi = 11,7, es decir, la variacion anual es 3,4 veces la binomial.
Un primer bootstrap binomial daba los tres cortes estables al 100 %, lo que describia el
supuesto y no los datos. Corregido, la estabilidad baja al 67,8 %, 53,0 % y 67,8 %, con los
anios vecinos recogiendo el resto. Lo que se afirma en el texto es que hay tres cambios de
tendencia y en que entorno estan, con incertidumbre de un anio.

El APC del periodo con la correccion es +1,180 % IC [+0,98 ; +1,38], que coincide con el que
ya reportaba el manuscrito: su intervalo estaba bien calculado.

**Otras notas cerradas.** Las tres de orientacion pasan a texto; en la de 5.4 se explica por
que son cinco pasos anidados y no cinco tecnicas. Escrita la entrada de 5.5.4. Anadida la
remision a la refutacion de la dilucion. El ordenamiento de los 33 departamentos va al
Apendice C con remision desde el cuerpo. La nota sobre la hipotesis refutada se retira porque
el texto ya la cumple.

## v60 — 18 de septiembre de 2026

**Escrita 5.8, analisis de sensibilidad.** Doce escenarios. El indice conserva el signo en
todos los anteriores a 2020; la magnitud varia entre un 5 % y un 51 %. El escenario que menos
lo mueve es el de cobertura estable (-7,2 %), que es justamente la objecion mas seria.

El resultado que sostiene la interpretacion del capitulo: al estimar el indice DENTRO de cada
regimen de codificacion, los tres regimenes anteriores a 2020 dan positivo y los tres
posteriores negativo. El cambio de signo ocurre dentro de la serie y no en la frontera entre
instrumentos, que es lo contrario de lo que se observaria si la inversion fuese un artefacto
del formulario.

**Resuelta la contradiccion de las cotas.** Era mas seria de lo anotado: la Seccion 4.2
prometia imputacion multiple como procedimiento principal, y el codigo nunca la implemento
--`src/sensibilidad.py` documenta la decision de no hacerla--. El manuscrito prometia un
procedimiento inexistente.

Reescritas 4.2 y la subseccion correspondiente del Capitulo 3. Ahora el procedimiento
declarado es el real: casos completos con cotas por ausencia, con las tres razones del
descarte --magnitud (educacion informada en el 96,80 %), naturaleza (la etnia es ausencia
estructural, cero no respuesta) y logica (la imputacion supone MAR, que es el supuesto que se
quiere poner a prueba)--. Se declara ademas que se pierde precision y que se gana no depender
de un supuesto incontrastable. Las ecuaciones de Rubin se conservan como referencia frente a
la cual se justifica la decision, de modo que siguen citadas.

Anadido `\label{sec:fase-sensibilidad}`.
