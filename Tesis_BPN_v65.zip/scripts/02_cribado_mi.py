"""
================================================================================
FASE 2 - CRIBADO DE VARIABLES POR INFORMACION MUTUA
Tesis: Desigualdades socioeconomicas, etnicas y territoriales en el bajo peso
       al nacer en Colombia, 1998-2024
================================================================================

QUE HACE
    Calcula la informacion mutua entre cada determinante candidato y el
    indicador de bajo peso al nacer, la normaliza como incertidumbre simetrica,
    construye una distribucion nula por permutacion especifica para cada
    variable y decide la retencion contra el percentil 95 de ese nulo.

SE EJECUTA DESPUES DEL EDA Y ANTES DE CUALQUIER MODELO.

CORRESPONDENCIA CON EL MANUSCRITO
    Seccion 4.4.2 del Capitulo 4 (Fase 2), definiciones formales en la
    Seccion 3.4.2 del Capitulo 3. Los cinco pasos del procedimiento declarado
    en la metodologia son los cinco bloques marcados PASO 1 a PASO 5.

ADVERTENCIA METODOLOGICA - LEER ANTES DE USAR LA SALIDA
    El descarte que produce este script se aplica UNICAMENTE al componente
    predictivo (Fase 7, los siete clasificadores). Los modelos logisticos
    multinivel de las Fases 4 y 5 conservan su especificacion completa,
    determinada por el marco de determinantes sociales y por la distincion
    entre confusor y mediador. Un confusor con informacion mutua marginal baja
    sigue siendo necesario para estimar sin sesgo el efecto de otro
    determinante (Heinze, Wallisch y Dunkler, 2018).

USO
    python 02_cribado_mi.py

REQUIERE
    pip install pandas numpy scikit-learn pyarrow

SALIDAS
    salidas/cribado_mi.csv          cuadro completo para el manuscrito
    salidas/cribado_mi_retenidas.txt lista de variables retenidas
    salidas/log_cribado_mi.txt
================================================================================
"""

from __future__ import annotations

import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.feature_selection import mutual_info_classif
from sklearn.metrics import mutual_info_score

# =============================================================================
# CONFIGURACION
# =============================================================================

RAIZ = Path(__file__).resolve().parent.parent
BASE = RAIZ / "datos" / "procesados" / "nacimientos_1998_2024.parquet"
DIR_SALIDAS = RAIZ / "salidas"
DIR_SALIDAS.mkdir(parents=True, exist_ok=True)

SEMILLA = 2024
N_PERMUTACIONES = 500   # replicas de la distribucion nula
K_VECINOS = 3           # k del estimador de Kraskov/Ross para el caso mixto
PERCENTIL_NULO = 95     # criterio de retencion

DESENLACE = "BPN"

# Determinantes categoricos: informacion mutua por conteo de frecuencias.
CATEGORICAS = [
    "NIV_EDUM", "NIV_EDUP", "SEG_SOCIAL", "EST_CIVM", "AREA_RES",
    "ETNIA", "SEXO", "MUL_PARTO", "TIPO_PARTO", "SIT_PARTO",
]

# Determinantes continuos o de recuento amplio: estimador por vecinos proximos.
CONTINUAS = ["EDAD_MADRE", "NUMCONSUL", "N_EMB", "N_HIJOSV"]

# Variables de la estructura jerarquica del diseno. NO son candidatas a
# eliminacion: definen los niveles del modelo multinivel. Se calculan solo para
# reportar su valor, con la advertencia de cardinalidad.
ESTRUCTURA = ["CODPTORE", "CODMUNRE"]

# Submuestra para el nulo por permutacion. Sobre 17 millones de filas, 500
# permutaciones completas son inviables; se remuestrea sin reemplazo. El sesgo
# de la informacion mutua depende del tamano de muestra, de modo que el nulo se
# calcula con EXACTAMENTE el mismo n que el valor observado, no con el n total.
N_SUBMUESTRA = 500_000


# =============================================================================
# FUNCIONES DE TEORIA DE LA INFORMACION
# =============================================================================

def entropia(s: pd.Series) -> float:
    """Entropia de Shannon en bits. Ecuacion 3.x del manuscrito."""
    p = s.value_counts(normalize=True, dropna=True).values
    p = p[p > 0]
    return float(-(p * np.log2(p)).sum())


def im_discreta(x: pd.Series, y: pd.Series) -> float:
    """
    Informacion mutua en bits entre dos variables discretas, por conteo de
    frecuencias sobre la tabla de contingencia conjunta.

    mutual_info_score devuelve nats; se convierte a bits dividiendo por ln(2)
    para que la escala sea la misma que la de entropia().
    """
    m = x.notna() & y.notna()
    if m.sum() == 0:
        return np.nan
    return float(mutual_info_score(x[m].astype(str), y[m].astype(str)) / np.log(2))


def im_mixta(x: pd.Series, y: pd.Series, semilla: int) -> float:
    """
    Informacion mutua entre un predictor continuo y un desenlace discreto,
    por el estimador de vecinos mas proximos de Kraskov et al. (2004) en la
    adaptacion de Ross (2014). Devuelve bits.
    """
    m = x.notna() & y.notna()
    if m.sum() == 0:
        return np.nan
    valor = mutual_info_classif(
        x[m].to_numpy(dtype=float).reshape(-1, 1),
        y[m].to_numpy(dtype=int),
        discrete_features=False,
        n_neighbors=K_VECINOS,
        random_state=semilla,
    )[0]
    return float(valor / np.log(2))


def incertidumbre_simetrica(im: float, hx: float, hy: float) -> float:
    """
    Informacion mutua normalizada por la media de las entropias marginales.
    Acotada en [0, 1]. Ecuacion 3.x del manuscrito.

    POR QUE NORMALIZAR: la informacion mutua bruta tiene como limite superior
    min(H(X), H(Y)), que crece con el numero de categorias. Sin normalizar,
    una variable de mil niveles domina el ranking por construccion.
    """
    if not np.isfinite(im) or (hx + hy) == 0:
        return np.nan
    return float(2.0 * im / (hx + hy))


# =============================================================================
# NULO POR PERMUTACION
# =============================================================================

def nulo_por_permutacion(x: pd.Series, y: pd.Series, continua: bool,
                         n_perm: int, rng: np.random.Generator) -> tuple[float, float, float]:
    """
    Distribucion nula de la informacion mutua para ESTA variable.

    POR QUE ES NECESARIO: la informacion mutua estimada sobre una muestra
    finita es sistematicamente positiva incluso bajo independencia, y el sesgo
    crece con el numero de celdas de la tabla conjunta (Steuer et al., 2002).
    Un umbral absoluto comun seria exigente para una variable dicotomica y laxo
    para una de mil niveles.

    COMO SE CONSTRUYE: se permuta el vector del desenlace, lo que preserva su
    prevalencia y la distribucion marginal del determinante pero destruye toda
    asociacion entre ambos. La cardinalidad de X y el tamano de muestra quedan
    intactos, que es justo lo que gobierna el sesgo.

    Devuelve (media, percentil 95, desviacion estandar) del nulo, en bits.
    """
    m = x.notna() & y.notna()
    xs, ys = x[m], y[m]

    valores = np.empty(n_perm, dtype=float)
    yv = ys.to_numpy()
    for i in range(n_perm):
        y_perm = pd.Series(rng.permutation(yv), index=xs.index)
        if continua:
            valores[i] = im_mixta(xs, y_perm, semilla=int(rng.integers(0, 2**31 - 1)))
        else:
            valores[i] = im_discreta(xs, y_perm)

    return (float(np.nanmean(valores)),
            float(np.nanpercentile(valores, PERCENTIL_NULO)),
            float(np.nanstd(valores)))


# =============================================================================
# PROCEDIMIENTO PRINCIPAL
# =============================================================================

def main() -> int:
    t0 = time.time()
    rng = np.random.default_rng(SEMILLA)
    log: list[str] = []

    def registrar(msg: str) -> None:
        print(msg)
        log.append(msg)

    registrar("=" * 78)
    registrar("FASE 2 - CRIBADO POR INFORMACION MUTUA")
    registrar("=" * 78)

    if not BASE.exists():
        registrar(f"ERROR: no se encuentra la base en {BASE}")
        registrar("Ejecuta primero 00_construir_base.ipynb con PILOTO = None.")
        return 1

    # -------------------------------------------------------------------------
    # PASO 0. Carga. Solo el conjunto de ENTRENAMIENTO.
    # -------------------------------------------------------------------------
    # CONTROL DE FUGA DE INFORMACION: calcular la informacion mutua sobre la
    # base completa y particionar despues significaria que la seleccion de
    # predictores ha visto los desenlaces del conjunto de prueba. Este script
    # exige que la columna PARTICION ya exista y filtra por ella.
    # Se leen los nombres de columna del esquema Parquet sin cargar datos, para
    # no traer 17 millones de filas solo para comprobar si existe PARTICION.
    import pyarrow.parquet as pq
    disponibles = set(pq.ParquetFile(BASE).schema.names)

    columnas = [c for c in ([DESENLACE] + CATEGORICAS + CONTINUAS + ESTRUCTURA)
                if c in disponibles]
    faltantes = set([DESENLACE] + CATEGORICAS + CONTINUAS + ESTRUCTURA) - disponibles
    if faltantes:
        registrar(f"AVISO: columnas ausentes en la base, se omiten: {sorted(faltantes)}")

    hay_particion = "PARTICION" in disponibles
    df = pd.read_parquet(BASE, columns=columnas + (["PARTICION"] if hay_particion else []))

    if hay_particion:
        df = df.loc[df["PARTICION"] == "entrenamiento"].drop(columns=["PARTICION"])
        registrar(f"Filtrado a la particion de entrenamiento: {len(df):,} registros")
    else:
        registrar("AVISO: no existe la columna PARTICION en la base.")
        registrar("       El cribado se esta calculando sobre TODA la base, lo que")
        registrar("       constituye fuga de informacion respecto del conjunto de prueba.")
        registrar("       Genera la particion antes de reportar estos resultados.")

    df = df.loc[df[DESENLACE].notna()].copy()
    registrar(f"Registros con desenlace observado: {len(df):,}")
    registrar(f"Prevalencia de BPN: {df[DESENLACE].mean() * 100:.2f} %")

    # Submuestra comun para observado y nulo, para que el sesgo sea comparable.
    if len(df) > N_SUBMUESTRA:
        df = df.sample(n=N_SUBMUESTRA, random_state=SEMILLA)
        registrar(f"Submuestra para el calculo: {len(df):,} registros "
                  f"(el mismo n se usa en el nulo)")

    y = df[DESENLACE].astype(int)
    h_y = entropia(y)
    registrar(f"Entropia del desenlace H(Y) = {h_y:.4f} bits")
    registrar("")

    filas = []

    def procesar(var: str, continua: bool, es_estructura: bool) -> None:
        if var not in df.columns:
            registrar(f"  {var:<12} NO PRESENTE en la base, se omite")
            return
        x = df[var]
        completitud = float(x.notna().mean())

        # ---------------------------------------------------------------------
        # PASO 1. Estimacion de la informacion mutua.
        # ---------------------------------------------------------------------
        im = im_mixta(x, y, SEMILLA) if continua else im_discreta(x, y)

        # ---------------------------------------------------------------------
        # PASO 2. Normalizacion como incertidumbre simetrica.
        # ---------------------------------------------------------------------
        h_x = entropia(x)
        u = incertidumbre_simetrica(im, h_x, h_y)

        # ---------------------------------------------------------------------
        # PASO 3. Distribucion nula por permutacion.
        # ---------------------------------------------------------------------
        nulo_med, nulo_p95, nulo_sd = nulo_por_permutacion(
            x, y, continua, N_PERMUTACIONES, rng
        )

        # ---------------------------------------------------------------------
        # PASO 4. Criterio de retencion: superar el percentil 95 del propio nulo.
        # ---------------------------------------------------------------------
        if es_estructura:
            decision = "estructura del diseno (no se criba)"
            retenida = True
        elif not np.isfinite(im):
            decision = "no evaluable"
            retenida = False
        elif im > nulo_p95:
            decision = "retenida"
            retenida = True
        else:
            decision = "descartada del componente predictivo"
            retenida = False

        # Razon senal/ruido: cuantas desviaciones del nulo por encima de su media.
        z = (im - nulo_med) / nulo_sd if (nulo_sd and nulo_sd > 0) else np.nan

        filas.append({
            "variable": var,
            "tipo": "continua" if continua else "categorica",
            "niveles": int(x.nunique(dropna=True)),
            "completitud": round(completitud, 4),
            "H_X_bits": round(h_x, 4),
            "IM_bits": round(im, 6) if np.isfinite(im) else np.nan,
            "incertidumbre_simetrica": round(u, 6) if np.isfinite(u) else np.nan,
            "nulo_media_bits": round(nulo_med, 6),
            "nulo_p95_bits": round(nulo_p95, 6),
            "z_sobre_nulo": round(z, 2) if np.isfinite(z) else np.nan,
            "decision": decision,
            "retenida": retenida,
        })
        registrar(f"  {var:<12} niveles={x.nunique(dropna=True):>5}  "
                  f"IM={im:.5f}  U={u:.5f}  p95nulo={nulo_p95:.5f}  -> {decision}")

    registrar("Determinantes categoricos")
    for v in CATEGORICAS:
        procesar(v, continua=False, es_estructura=False)

    registrar("")
    registrar("Determinantes continuos o de recuento")
    for v in CONTINUAS:
        procesar(v, continua=True, es_estructura=False)

    registrar("")
    registrar("Variables de la estructura jerarquica (se reportan, no se criban)")
    for v in ESTRUCTURA:
        procesar(v, continua=False, es_estructura=True)

    # -------------------------------------------------------------------------
    # PASO 5. Redundancia entre determinantes retenidos.
    # -------------------------------------------------------------------------
    # Criterio de maxima relevancia y minima redundancia (Peng, Long y Ding,
    # 2005): entre las retenidas, se calcula la informacion mutua PAR A PAR.
    # Un par con U alta mide la misma dimension social; la metodologia declara
    # que se conserva la de mejor completitud.
    tabla = pd.DataFrame(filas).sort_values(
        "incertidumbre_simetrica", ascending=False, na_position="last"
    )

    candidatas = [f["variable"] for f in filas
                  if f["retenida"] and f["variable"] not in ESTRUCTURA]
    registrar("")
    registrar("Redundancia entre retenidas (incertidumbre simetrica par a par)")
    redundancia = []
    for i, a in enumerate(candidatas):
        for b in candidatas[i + 1:]:
            im_ab = im_discreta(df[a], df[b])
            u_ab = incertidumbre_simetrica(im_ab, entropia(df[a]), entropia(df[b]))
            redundancia.append({"var_a": a, "var_b": b,
                                "U_ab": round(u_ab, 4) if np.isfinite(u_ab) else np.nan})
            if np.isfinite(u_ab) and u_ab > 0.30:
                registrar(f"  ALTA REDUNDANCIA  {a} <-> {b}  U={u_ab:.3f}  "
                          f"(revisar: conservar la de mejor completitud)")

    # -------------------------------------------------------------------------
    # SALIDAS
    # -------------------------------------------------------------------------
    tabla.to_csv(DIR_SALIDAS / "cribado_mi.csv", index=False, encoding="utf-8")
    pd.DataFrame(redundancia).to_csv(
        DIR_SALIDAS / "cribado_mi_redundancia.csv", index=False, encoding="utf-8"
    )
    retenidas = tabla.loc[tabla["retenida"], "variable"].tolist()
    (DIR_SALIDAS / "cribado_mi_retenidas.txt").write_text(
        "\n".join(retenidas), encoding="utf-8"
    )

    registrar("")
    registrar(f"Retenidas: {len(retenidas)} de {len(tabla)}")
    registrar(f"Descartadas del componente predictivo: "
              f"{[f['variable'] for f in filas if not f['retenida']]}")
    registrar(f"Tiempo total: {time.time() - t0:.1f} s")
    registrar("")
    registrar("RECORDATORIO: este descarte NO se aplica a los modelos multinivel")
    registrar("de las Fases 4 y 5. Su especificacion es conceptual, no empirica.")

    (DIR_SALIDAS / "log_cribado_mi.txt").write_text("\n".join(log), encoding="utf-8")
    return 0


if __name__ == "__main__":
    sys.exit(main())
