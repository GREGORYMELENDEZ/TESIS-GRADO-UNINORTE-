@echo off
REM ======================================================================
REM  COMPILAR, VERIFICAR Y GUARDAR UNA VERSION NUEVA
REM
REM  Doble clic sobre este archivo. Hace las cuatro pasadas que exige
REM  bibtex, despues los controles de calidad, y si todo sale limpio guarda
REM  DOS cosas con el mismo numero de version:
REM
REM      Tesis_BPN_vista_previa_v<N>.pdf
REM      Tesis_BPN_v<N>.zip
REM
REM  Las dos quedan en la carpeta de versiones, que es la que ya contiene
REM  las anteriores.
REM
REM  IMPORTANTE: ESTA CARPETA ES LA DE TRABAJO Y NO SE MUEVE. El zip de
REM  cada version es la copia congelada; no hay que editarlo nunca, solo
REM  sirve para volver atras.
REM
REM  HISTORIA DE DOS ERRORES, PARA QUE NO SE REPITAN
REM
REM    1) Hasta la v64 esto guardaba ademas una carpeta Tesis_BPN_vNN\ al
REM       lado del zip. Se retiro: duplicaba el espacio, y sobre todo
REM       llenaba la carpeta de directorios parecidos entre los que era
REM       facil confundir cual era el vivo.
REM
REM    2) La carpeta de trabajo se llamaba Tesis_BPN_v60 pese a contener la
REM       version en curso. Parecia una copia congelada mas y se borro por
REM       error. Ahora se llama MANUSCRITO, que no se confunde con nada.
REM ======================================================================

setlocal enabledelayedexpansion
cd /d "%~dp0"
chcp 65001 >nul

echo.
echo ======================================================================
echo   COMPILANDO  -  son cuatro pasadas
echo ======================================================================
echo.

where pdflatex >nul 2>&1
if errorlevel 1 (
    echo   ERROR: no encuentro pdflatex en el PATH.
    echo   Instala MiKTeX, o compila en Overleaf.
    echo.
    pause
    exit /b 1
)

echo   [1 de 4] pdflatex ...
pdflatex -interaction=nonstopmode main.tex >nul 2>&1
echo   [2 de 4] bibtex ...
bibtex main >nul 2>&1
echo   [3 de 4] pdflatex ...
pdflatex -interaction=nonstopmode main.tex >nul 2>&1
echo   [4 de 4] pdflatex ...
pdflatex -interaction=nonstopmode main.tex >nul 2>&1

echo.
echo ======================================================================
echo   CONTROLES  -  los tres tienen que dar CERO
echo ======================================================================
echo.

for /f %%A in ('findstr /c:"Citation" main.log ^| findstr /c:"undefined" ^| find /c /v ""') do set CIT=%%A
for /f %%A in ('findstr /c:"Reference" main.log ^| findstr /c:"undefined" ^| find /c /v ""') do set REF=%%A
for /f %%A in ('findstr /b /c:"!" main.log ^| find /c /v ""') do set ERR=%%A

echo   Citas sin resolver ........ %CIT%
echo   Referencias sin resolver .. %REF%
echo   Errores de LaTeX .......... %ERR%

REM Avisos: no impiden entregar, pero conviene verlos.
for /f %%A in ('findstr /c:"Overfull" main.log ^| find /c /v ""') do set OVER=%%A
echo   Lineas que se salen ....... %OVER%   ^(avisos, no errores^)

REM Las notas rojas que quedan, que es la cuenta que de verdad importa.
if exist main.pnd (
    for /f %%A in ('findstr /c:"pndentrada" main.pnd ^| find /c /v ""') do set PND=%%A
    echo   Notas rojas pendientes .... !PND!
)
echo.

if not "%CIT%%REF%%ERR%"=="000" goto :problemas

REM ----------------------------------------------------------------------
REM  Donde se guarda y con que numero
REM ----------------------------------------------------------------------
REM  Las dos cosas las decide siguiente_version.ps1, que busca la carpeta
REM  de versiones subiendo nivel por nivel en vez de contar un numero fijo
REM  de niveles. Asi esto sigue funcionando si la carpeta de trabajo se
REM  mueve, que es lo que rompio la version anterior de este archivo.
REM
REM  Se lee con set /p desde un temporal y no con for /f porque asi la
REM  orden de PowerShell no pasa por el interprete de cmd y sus comillas
REM  no se rompen.
set "BASE="
set "NUEVA="
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0siguiente_version.ps1" > "%TEMP%\bpn_ver.txt" 2>nul
if exist "%TEMP%\bpn_ver.txt" (
    set /p BASE=<"%TEMP%\bpn_ver.txt"
    for /f "skip=1 delims=" %%L in ('type "%TEMP%\bpn_ver.txt"') do if not defined NUEVA set "NUEVA=%%L"
)
del "%TEMP%\bpn_ver.txt" >nul 2>&1

if not defined BASE goto :sin_numero
if not defined NUEVA goto :sin_numero
echo %NUEVA%| findstr /r "^[0-9][0-9]*$" >nul || goto :sin_numero

if exist "%BASE%\Tesis_BPN_v%NUEVA%.zip" (
    echo   ----------------------------------------------------------------
    echo    AVISO: Tesis_BPN_v%NUEVA%.zip ya existe. No se sobrescribe.
    echo   ----------------------------------------------------------------
    goto :fin
)

echo   ----------------------------------------------------------------
echo    TODO LIMPIO.  Esta version es la  v%NUEVA%
echo   ----------------------------------------------------------------
echo.

REM ----------------------------------------------------------------------
REM  1) El PDF de vista previa
REM ----------------------------------------------------------------------
copy /y "%~dp0main.pdf" "%BASE%\Tesis_BPN_vista_previa_v%NUEVA%.pdf" >nul 2>&1
if exist "%BASE%\Tesis_BPN_vista_previa_v%NUEVA%.pdf" (
    echo    PDF guardado:  Tesis_BPN_vista_previa_v%NUEVA%.pdf
) else (
    echo    AVISO: el PDF no se copio.
)

REM ----------------------------------------------------------------------
REM  2) El zip, que es el archivo de la version
REM ----------------------------------------------------------------------
REM  Se deja fuera lo que LaTeX regenera solo --aux, log, toc y compania--.
REM  El .bbl SI entra: es lo que permite recompilar la version sin volver a
REM  pasar bibtex. -Exclude actua sobre los nombres del primer nivel, que
REM  es justo donde estan esos auxiliares; las subcarpetas entran enteras.
powershell -NoProfile -Command "Get-ChildItem -Path '%~dp0*' -Exclude '*.aux','*.log','*.out','*.toc','*.lof','*.lot','*.blg','*.pnd','*.synctex.gz' | Compress-Archive -DestinationPath '%BASE%\Tesis_BPN_v%NUEVA%.zip' -Force" >nul 2>&1
if exist "%BASE%\Tesis_BPN_v%NUEVA%.zip" (
    echo    ZIP guardado:  Tesis_BPN_v%NUEVA%.zip
) else (
    echo    AVISO: el zip no se creo. Comprime a mano esta carpeta.
)

echo.
echo    Las dos quedaron en:  %BASE%
goto :fin

REM ----------------------------------------------------------------------
:sin_numero
echo   ----------------------------------------------------------------
echo    No pude averiguar el numero de version automaticamente.
echo   ----------------------------------------------------------------
echo.
set /p NUEVA=   Escribe el numero que le toca (solo digitos):
if not defined NUEVA goto :fin
echo %NUEVA%| findstr /r "^[0-9][0-9]*$" >nul || (
    echo    Eso no es un numero. No se guarda nada.
    goto :fin
)
if not defined BASE set "BASE=%~dp0.."
echo.
copy /y "%~dp0main.pdf" "%BASE%\Tesis_BPN_vista_previa_v%NUEVA%.pdf" >nul 2>&1
powershell -NoProfile -Command "Get-ChildItem -Path '%~dp0*' -Exclude '*.aux','*.log','*.out','*.toc','*.lof','*.lot','*.blg','*.pnd','*.synctex.gz' | Compress-Archive -DestinationPath '%BASE%\Tesis_BPN_v%NUEVA%.zip' -Force" >nul 2>&1
echo    Guardado como v%NUEVA%.
goto :fin

REM ----------------------------------------------------------------------
:problemas
echo   ----------------------------------------------------------------
echo    HAY PROBLEMAS. No se guarda version nueva.
echo   ----------------------------------------------------------------
echo.
if not "%ERR%"=="0" (
    echo    Errores de LaTeX:
    echo.
    findstr /b /c:"!" main.log
    echo.
)
if not "%CIT%"=="0" (
    echo    Citas sin resolver:
    echo.
    findstr /c:"Citation" main.log ^| findstr /c:"undefined"
    echo.
)
if not "%REF%"=="0" (
    echo    Referencias sin resolver:
    echo.
    findstr /c:"Reference" main.log ^| findstr /c:"undefined"
    echo.
)
echo    Pasale main.log a Claude y lo revisa.

:fin
echo.
pause
endlocal
