"""
Tabla 4.1 - Conformacion de la muestra analitica
================================================
Recorre TODOS los archivos anuales de nacimientos de las EEVV y calcula, en una
sola pasada, los conteos de cada etapa de exclusion. Imprime el resultado y
genera el codigo LaTeX del cuadro listo para pegar en la tesis.

USO
---
1. Pon todos los .sav (o .csv) en una carpeta, uno por anio.
2. Ajusta CARPETA aqui abajo.
3. Ejecuta:   python tabla_4_1_flujo_muestra.py

Requiere:  pip install pandas pyreadstat
"""

from pathlib import Path
import pandas as pd
import numpy as np
import pyreadstat

# --------------------------------------------------------------- CONFIGURACION
CARPETA = Path("datos/crudos")     # <-- carpeta con los archivos anuales
SALIDA  = Path("salidas")
SALIDA.mkdir(parents=True, exist_ok=True)

# Nombres que puede tomar cada concepto segun el anio (ver Apendice B)
ALIAS = {
    "PESO_NAC":  ["PESO_NAC", "peso_nac"],
    "T_GES":     ["T_GES", "t_ges"],
    "CODPTORE":  ["CODPTORE", "codptore"],
    "CODMUNRE":  ["CODMUNRE", "codmunre"],
    "CODPRES":   ["CODPRES", "codpres"],
    "ANO":       ["ANO", "ano"],
}

# Codigos de "sin informacion"
SIN_INFO = {"PESO_NAC": [9], "T_GES": [6, 9]}

# CODPRES trae el codigo ISO del pais de residencia de la madre.
# 170 = Colombia. Cualquier otro valor indica residencia en el extranjero.
COD_COLOMBIA = 170
COD_PAIS_SIN_INFO = 999


def columna(df, concepto):
    """Devuelve la serie del concepto, sea cual sea el nombre que tenga ese anio."""
    for nombre in ALIAS[concepto]:
        if nombre in df.columns:
            return pd.to_numeric(df[nombre], errors="coerce")
    return pd.Series([np.nan] * len(df), index=df.index)


def leer(ruta):
    if ruta.suffix.lower() == ".sav":
        df, _ = pyreadstat.read_sav(str(ruta), encoding="LATIN1")
    else:
        df = pd.read_csv(ruta, low_memory=False)
    df.columns = [c.strip() for c in df.columns]
    return df


def procesar(ruta):
    df = leer(ruta)
    n0 = len(df)

    peso = columna(df, "PESO_NAC")
    tges = columna(df, "T_GES")
    dpto = columna(df, "CODPTORE")
    muni = columna(df, "CODMUNRE")
    pres = columna(df, "CODPRES")

    # Exclusion 1: sin peso al nacer informado
    e1 = peso.isna() | peso.isin(SIN_INFO["PESO_NAC"])

    # Exclusion 2: sin tiempo de gestacion informado (entre los que sobreviven a e1)
    e2 = ~e1 & (tges.isna() | tges.isin(SIN_INFO["T_GES"]))

    # Exclusion 3: sin territorio de residencia identificable
    e3 = ~e1 & ~e2 & (dpto.isna() | muni.isna())

    # Exclusion 4: madre con residencia habitual en el extranjero.
    # OJO: CODPRES vale 170 (Colombia) para la inmensa mayoria de registros.
    # Solo se excluye cuando el codigo es de otro pais.
    e4 = (~e1 & ~e2 & ~e3
          & pres.notna()
          & (pres != COD_COLOMBIA)
          & (pres != COD_PAIS_SIN_INFO))

    incluidos = n0 - int(e1.sum()) - int(e2.sum()) - int(e3.sum()) - int(e4.sum())
    return {
        "archivo": ruta.name,
        "anio": int(columna(df, "ANO").dropna().mode().iloc[0]) if columna(df, "ANO").notna().any() else None,
        "base_original": n0,
        "excl_1_sin_peso": int(e1.sum()),
        "excl_2_sin_gestacion": int(e2.sum()),
        "excl_3_sin_territorio": int(e3.sum()),
        "excl_4_residencia_exterior": int(e4.sum()),
        "muestra_analitica": incluidos,
    }


def main():
    archivos = sorted([p for p in CARPETA.iterdir()
                       if p.suffix.lower() in (".sav", ".csv")])
    if not archivos:
        raise SystemExit(f"No se encontraron archivos en {CARPETA.resolve()}")

    filas = []
    for ruta in archivos:
        print(f"  procesando {ruta.name} ...", flush=True)
        filas.append(procesar(ruta))

    det = pd.DataFrame(filas)
    det.to_csv(SALIDA / "tabla_4_1_por_anio.csv", index=False)

    tot = det.drop(columns=["archivo", "anio"]).sum()
    n0 = int(tot["base_original"])

    print("\n" + "=" * 62)
    print("TABLA 4.1 - CONFORMACION DE LA MUESTRA ANALITICA")
    print("=" * 62)
    etapas = [
        ("Base original", n0, None),
        ("Exclusion 1. Sin peso al nacer informado", -int(tot["excl_1_sin_peso"]), None),
        ("Exclusion 2. Sin tiempo de gestacion", -int(tot["excl_2_sin_gestacion"]), None),
        ("Exclusion 3. Sin territorio de residencia", -int(tot["excl_3_sin_territorio"]), None),
        ("Exclusion 4. Residencia en el exterior", -int(tot["excl_4_residencia_exterior"]), None),
        ("Muestra analitica", int(tot["muestra_analitica"]), None),
    ]
    for nombre, valor, _ in etapas:
        print(f"{nombre:<45} {valor:>14,}   ({abs(valor)/n0*100:5.2f} %)")

    # --- LaTeX listo para pegar
    fmt = lambda x: f"{x:,}".replace(",", ".")
    tex = f"""% Cifras generadas por scripts/tabla_4_1_flujo_muestra.py
Base original & Nacidos vivos, EEVV--DANE, 1998--2024 & {fmt(n0)} \\\\
Exclusión 1 & Registros sin peso al nacer informado & --{fmt(int(tot['excl_1_sin_peso']))} \\\\
Exclusión 2 & Registros sin tiempo de gestación informado & --{fmt(int(tot['excl_2_sin_gestacion']))} \\\\
Exclusión 3 & Registros sin municipio o departamento de residencia & --{fmt(int(tot['excl_3_sin_territorio']))} \\\\
Exclusión 4 & Madres con residencia habitual en el exterior & --{fmt(int(tot['excl_4_residencia_exterior']))} \\\\
\\midrule
Muestra analítica & Nacimientos incluidos en el análisis & {fmt(int(tot['muestra_analitica']))} \\\\
"""
    (SALIDA / "tabla_4_1.tex").write_text(tex, encoding="utf-8")
    print(f"\nGenerados:\n  {SALIDA/'tabla_4_1_por_anio.csv'}\n  {SALIDA/'tabla_4_1.tex'}")


if __name__ == "__main__":
    main()
